﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Web;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Deployment;

namespace CheckEffectiveProperties
{
    public class SPObjType
    {
        public Guid objectGuid;
        public object obj;
        public string url;
        public string siteRelativeUrl;
        public SPDeploymentObjectType objType;
        public StringBuilder message = new StringBuilder(2000);
        public SPBasePermissions currUserRights;
        public SPBasePermissions testUser;
        public SPBasePermissions anonymousMask;
        public bool? isAnonymousEnabled = null;

        
        public static string EnumeratePermission(SPBasePermissions Mask)
        {
            StringBuilder sb = new StringBuilder(100);
            sb.AppendFormat("Perm Mask  -  Hex: {0} Binary {1}\n", ((ulong)Mask).ToString("x8"), Convert.ToString((Int64)Mask, 2));
            foreach (string permName in Enum.GetNames(typeof(SPBasePermissions)))
            {
                ulong i = (ulong)Mask & (ulong)(Enum.Parse(typeof(SPBasePermissions), permName));
                if (i > 0)
                {
                    sb.Append(String.Format("    {0} Hex [{1}] Binary [{2}]\n", permName, i.ToString("x8"),  Convert.ToString((Int64)i, 2)));
                }
            }
            return sb.ToString();
        }
        public void GetFile(SPFile File, SPBasePermissions Mask)
        {
            try
            {
                byte[] binFile = File.OpenBinary();
                ASCIIEncoding asc = new ASCIIEncoding();
                string fileContent = asc.GetString(binFile);
                message.AppendFormat("\n*** File {0} content:\n\n{1}\n\n", File.Name, fileContent);
                message.Append("\n*** End File");
                if (File.Item != null)
                {
                    message.AppendFormat("\n*** Anonymous has rights on File {0}: [{1}]\n\n", File.Name, File.Item.DoesUserHavePermissions(Mask));
                }
                else
                {
                    message.AppendFormat("\n*** Unable to test Anonymous rights on File {0}\n\n", File.Name);
                }
            }
            catch (Exception ex)
            {
                message.AppendFormat("\n\n***************  Error opening file {0}: {1}  ************\n\n", File.Name, ex.Message);
                
            }

        }
    }




    // The class below was originally created by Sanjay Narang to identify the object type from a URL
    // The code for this intent is found here: http://blogs.msdn.com/b/sanjaynarang/archive/2009/04/07/find-sharepoint-object-type-from-url.aspx
    //
    // It was modified to check properties and cascade access (Anonymous | Current User | GivenUser) 
    //    for an object pointed by Rodney Viana
    // You have to agree with this license to use this code/application: http://rodneyviana.codeplex.com/license
    // Details of the implementation can be found at: http://blogs.msdn.com/rodneyviana
    // This project can be downloaded at: http://rodneyviana.codeplex.com/releases/view/19103

    class SanjayMossUtilities
    {
        public SPObjType GetObjectTypeFromURL(string passedUrl, string User)
        {
            SPObjType oType = new SPObjType();
            oType.objType = SPDeploymentObjectType.Invalid;

            oType.objectGuid = Guid.Empty;

            SPSite site = null;
            SPWeb web = null;
            SPList list = null;
            oType.obj = null;
            oType.url = null;
            oType.siteRelativeUrl = null;
            NameValueCollection queryParams = null;

            oType.url = GetModifiedUrl(passedUrl, out queryParams);

            try
            {
                site = new SPSite(oType.url);
                oType.message.AppendFormat("**** Start Miscellaneous for Site {0}\n", site.Url);
                oType.message.AppendFormat("IIS Allow Anonymous:  [{0}]\n", site.IISAllowsAnonymous);
                oType.message.AppendFormat("IIS is impersonating: [{0}]\n", site.Impersonating);
                oType.message.AppendFormat("Zone:                 [{0}]\n", site.Zone.ToString());
                oType.message.AppendFormat("Host Name:            [{0}]\n", site.HostName);
                oType.message.AppendFormat("Write Locked:         [{0}]\n", site.WriteLocked);
                oType.message.Append("**** End Miscellaneous for Site\n");

                web = site.OpenWeb();
                oType.message.AppendFormat("**** Start Miscellaneous for Web {0}\n", web.Url);
                oType.message.AppendFormat("Web Allow Anonymous:  [{0}]\n", web.AllowAnonymousAccess);
                oType.message.AppendFormat("Anonymous Access to Lists and Libraries:  [{0}]\n", web.AnonymousState.ToString());
                if (web.AllowAnonymousAccess)
                {
                    oType.message.Append("********* Start of List of Rights to anonymous in this web\n");
                    oType.message.Append(SPObjType.EnumeratePermission(web.AnonymousPermMask64));
                    oType.message.Append("********* End of List of Rights to anonymous in this web\n\n");
                }

                if (!String.IsNullOrEmpty(User))
                {
                    oType.message.AppendFormat("********* Start of List of Rights for User {0}\n", User);
                    oType.message.Append(SPObjType.EnumeratePermission(web.GetUserEffectivePermissions(User)));
                    oType.message.Append("********* End of List of Rights\n\n");

                }
                string curUser = Environment.UserDomainName + "\\" + Environment.UserName;
                if (User.ToLower().Trim() != curUser.ToLower().Trim())
                {
                    oType.message.AppendFormat("********* Start of List of Rights for Current User {0}\n", curUser);
                    oType.message.Append(SPObjType.EnumeratePermission(web.GetUserEffectivePermissions(curUser)));
                    oType.message.Append("********* End of List of Rights\n\n");
                }
                oType.message.Append("**** End Miscellaneous for Web\n\n");
                


                if (oType.url.Equals(site.Url, StringComparison.OrdinalIgnoreCase))
                {
                    oType.objectGuid = site.ID;
                    oType.objType = SPDeploymentObjectType.Site;
                    
                    return oType;
                }

                if (oType.url.Equals(web.Url, StringComparison.OrdinalIgnoreCase))
                {
                    oType.objectGuid = web.ID;
                    oType.objType = SPDeploymentObjectType.Web;
                    return oType;
                }

                oType.siteRelativeUrl = oType.url.TrimStart(web.Url.ToCharArray());

                try
                {
                    list = web.GetList(oType.url);
                }
                catch(Exception ex)
                {
                    oType.message.AppendFormat("\n\n  *******  Error trying to retrieve List : {0}  ***** \n\n", ex.Message);
                    list = null;
                }
      


                if (null != list )
                {
                    oType.objectGuid = list.ID;
                    oType.objType = SPDeploymentObjectType.List;

                    oType.message.AppendFormat("**** Start Miscellaneous for List {0} at {1}\n", list.Title, list.DefaultViewUrl);
                    oType.message.AppendFormat("Access to Template List is Restricted     :  [{0}]\n", list.RestrictedTemplateList);
                    oType.message.AppendFormat("Users Access Limited to Items they Created:  [{0}]\n", (list.ReadSecurity==2));
                    oType.message.AppendFormat("Anonymous can access                      :  [{0}]\n", list.DoesUserHavePermissions(list.AnonymousPermMask64));
                    oType.message.AppendFormat("Everyone can view List                    :  [{0}]\n", list.AllowEveryoneViewItems);


                    oType.message.Append("********* Start of List of Rights to anonymous in this List\n");
                    oType.message.Append(SPObjType.EnumeratePermission(list.AnonymousPermMask64));
                    oType.message.Append("********* End of List of Rights to anonymous in this List\n\n");

                    if (!String.IsNullOrEmpty(User))
                    {
                        oType.message.AppendFormat("********* Start of List of Rights for User {0}\n", User);
                        oType.message.Append(SPObjType.EnumeratePermission(list.GetUserEffectivePermissions(User)));
                        oType.message.Append("********* End of List of Rights\n\n");

                    }
                    if (User.ToLower().Trim() != curUser.ToLower().Trim())
                    {
                        oType.message.AppendFormat("********* Start of List of Rights for Current User {0}\n", curUser);
                        oType.message.Append(SPObjType.EnumeratePermission(list.GetUserEffectivePermissions(curUser)));
                        oType.message.Append("********* End of List of Rights\n\n");
                    }
                    oType.message.Append("**** End Miscellaneous for List\n\n");

                    if (oType.siteRelativeUrl.Equals(list.RootFolder.Url, StringComparison.OrdinalIgnoreCase))
                    {
                        return oType;
                    }
                }

                // if we are here, it means URL is none of these: 
                // site, web, list
                // So, it can be either file, folder or a list item.
                // Finding that is intricated.

                oType.obj = web.GetObject(oType.url);

                if (null != oType.obj)
                {
                    SPListItem item = (oType.obj as SPListItem);
                    if (item != null)
                    {
                        if (!String.IsNullOrEmpty(User))
                        {
                            oType.message.AppendFormat("**** Start Miscellaneous for List Item {0} at {1}\n", item.Name, item.Url);
                            oType.message.AppendFormat("Anonymous has access to list item    :  [{0}]\n", item.DoesUserHavePermissions( list.AnonymousPermMask64));
                            oType.message.AppendFormat("Permission Inheritance is broken     :  [{0}]\n", item.HasUniqueRoleAssignments);


                            //                    oType.message.Append(SPObjType.EnumeratePermission(web.AnonymousPermMask64));

                            oType.message.AppendFormat("********* Start of List of Rights for User {0}\n", User);
                            oType.message.Append(SPObjType.EnumeratePermission(item.GetUserEffectivePermissions(User)));
                            oType.message.Append("********* End of List of Rights\n\n");

                        }
                        if (User.ToLower().Trim() != curUser.ToLower().Trim())
                        {
                            oType.message.AppendFormat("********* Start of List of Rights for Current User {0}\n", curUser);
                            oType.message.Append(SPObjType.EnumeratePermission(item.GetUserEffectivePermissions(curUser)));
                            oType.message.Append("********* End of List of Rights\n\n");
                        }
                        oType.message.AppendFormat("********* Item Xml\n", curUser);
                        oType.message.AppendFormat("{0}\n", item.Xml);

                        oType.message.Append("********* End of Item XML\n\n");
                        oType.message.AppendFormat("********* Role Assignments Xml\n", curUser);
                        oType.message.AppendFormat("{0}\n", item.RoleAssignments.Xml);

                        oType.message.Append("********* End of Role Assignments Xml\n\n");


                        oType.message.Append("**** End Miscellaneous for List Item\n\n");
                        
                    }
                    if (oType.obj is SPFile)
                    {
                        // Generally, we get here for Forms Pages, 
                        // such as DispForm.aspx, AllItems.aspx
                        // so, a SPFile object could be a list item Or
                        // a folder in a list or a Folder

                        // Pages in root of the web are also returned as 
                        // SPFiles e.g. http://moss/default.aspx

                        // The URLs that point to a file in doc lib are 
                        // returned as SPListItem by GetObject method
                        //

                        SPFile file = oType.obj as SPFile;

                        if (null != queryParams)
                        {
                            // The logic to identify folder or item has
                            // been explained in ValidateQueryString
                            string idValue = queryParams["ID"];
                            string folderValue = queryParams["RootFolder"];
                            if (null != idValue)
                            {
                                item = list.GetItemById(int.Parse(idValue));
                                oType.objectGuid = item.UniqueId;
                                oType.objType = SPDeploymentObjectType.ListItem;
                                return oType;
                            }
                            else if (null != folderValue)
                            {
                                SPFolder folder = web.GetFolder(folderValue);
                                oType.objectGuid = folder.UniqueId;
                                oType.objType = SPDeploymentObjectType.Folder;
                                return oType;
                            }
                            else
                            {
                                // Deployyment Object Type is: Invalid, so no need
                                // to do anything
                            }
                        }
                        else
                        {
                            oType.objectGuid = file.UniqueId;
                            oType.objType = SPDeploymentObjectType.File;
                            oType.GetFile(file, web.AnonymousPermMask64);
                            return oType;
                        }
                    }
                    else if (oType.obj is SPFolder)
                    {
                        SPFolder folder = oType.obj as SPFolder;
                        oType.objectGuid = folder.UniqueId;
                        oType.objType = SPDeploymentObjectType.Folder;
                        return oType;
                    }
                    else if (oType.obj is SPListItem)
                    {

                        item = oType.obj as SPListItem;

                        // item can contain a folder of file also. e.g. 
                        // http://moss.litwareinc.com/Documents/folderinlibrary
                        // http://moss.litwareinc.com/Documents/FolderInLibrary/File2.doc

                        if (null != item.Folder)
                        {
                            oType.objectGuid = item.Folder.UniqueId;
                            oType.objType = SPDeploymentObjectType.Folder;
                            return oType;
                        }
                        else if (null != item.File)
                        {
                            oType.objectGuid = item.File.UniqueId;
                            oType.objType = SPDeploymentObjectType.File;
                            oType.GetFile(item.File, web.AnonymousPermMask64);

                            return oType;
                        }



                        oType.objectGuid = item.UniqueId;
                        oType.objType = SPDeploymentObjectType.ListItem;
                        return oType;
                    }
                }

            }
            finally
            {
                if (web != null)
                {
                    web.Dispose();
                }
                if (site != null)
                {
                    site.Dispose();
                }
            }
            return oType;
        }

        private string GetModifiedUrl(string url, out NameValueCollection queryParams)
        {
            string modUrl = url; //modified url
            string querystring = string.Empty;
            queryParams = null;

            // if it's a site or web or folder, user can pass '/' at 
            // the end, which we need to trim
            if (url.EndsWith("/"))
            {
                modUrl = url.TrimEnd(new char[] { '/' });
            }

            // we need to get the URL without query string as it creates
            // problem getting the parent folder
            if (url.Contains("?"))
            {

                int tmp = url.IndexOf("?");
                modUrl = url.Substring(0, tmp);
                querystring = url.Substring(tmp + 1);

                queryParams = HttpUtility.ParseQueryString(querystring);
                // apply custom rules
                ValidateQueryString(queryParams);
            }

            return modUrl;
        }

        private void ValidateQueryString(NameValueCollection queryParams)
        {
            // when there's query string in the URL, the URL can point to a 
            // list item (in a list) or a folder.           
            // For example if an item is a folder 
            // 'FolderInTasksList' the URL of item would look like this    
            // http://moss.litwareinc.com/Lists/Tasks/DispForm.aspx?ID=2&RootFolder=/Lists/Tasks/FolderInTasksList OR
            // http://moss.litwareinc.com/Lists/Tasks/DispForm.aspx?ID=2&RootFolder=%2fLists%2fTasks%2fFolderInTasksList
            // 
            // And if we need Url of the folder, it would be like this:
            // http://moss.litwareinc.com/Lists/Tasks/AllItems.aspx?RootFolder=%2fLists%2fTasks%2fFolderInTasksList&FolderCTID=&View=%7bD8E1251D%2d829B%2d4FCE%2d9127%2d5E4FC6E6A5C4%7d
            //
            // From the above two examples, I'm applying the following 
            // rules on the query string 
            // 1. It can contain only these keys: ID, RootFolder, FolderCTID, View
            //    If there's any other key, i would treat that as invalid query string
            //
            // 2. ID and RootFolder should never be empty
            //    otherwise, raise exception here rather than hitting that later
            //
            // 3. the query string has to contain at least one of the following
            //    a. ID, b. RootFolder

            // Build a string collection with possible values. For comparison, 
            // we'll use lower case only
            StringCollection strColl = new StringCollection();
            strColl.Add("ID".ToLower());
            strColl.Add("RootFolder".ToLower());
            strColl.Add("FolderCTID".ToLower());
            strColl.Add("View".ToLower());

            // Apply the Rules
            bool hasID = false;
            bool hasRootFolder = false;

            Console.WriteLine();
            foreach (string str in queryParams.AllKeys)
            {
                // can be used for debugging
                // Console.WriteLine("Name: " + str + " | Value: " + queryParams[str]);

                // Rule 1
                if (!(strColl.Contains(str.ToLower())))
                {
                    throw new ArgumentException("Invalid argument in passed query string");
                }
                // Rule 2
                if (str.Equals("id", StringComparison.OrdinalIgnoreCase))
                {
                    hasID = true;
                    if (queryParams[str].Equals(String.Empty))
                    {
                        throw new ArgumentException("Query string parameter \"" + str + "\" can not be empty.");
                    }
                }
                // Rule 2
                if (str.Equals("rootfolder", StringComparison.OrdinalIgnoreCase))
                {
                    hasRootFolder = true;
                    if (queryParams[str].Equals(String.Empty))
                    {
                        throw new ArgumentException("Query string parameter \"" + str + "\" can not be empty.");
                    }
                }
            }
            // Rule 3
            Console.WriteLine();
            if (!(hasID || hasRootFolder))
            {
                throw new ArgumentException("Query string must have at least one parameter from these: ID and RootFolder");
            }
        }

    }
}
