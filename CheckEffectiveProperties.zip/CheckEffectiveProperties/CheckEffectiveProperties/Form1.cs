﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CheckEffectiveProperties
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            textURL.Text = "http://" + Environment.MachineName.ToLower();
            textLogin.Text = Environment.UserDomainName + "\\" + Environment.UserName;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SanjayMossUtilities mu = new SanjayMossUtilities();
            textResults.Text = "";
            textResults.Refresh();
            SPObjType ot = new SPObjType();
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                ot = mu.GetObjectTypeFromURL(textURL.Text, textLogin.Text);
            }
            catch (Exception ex)
            {
                ot.message.AppendFormat("******* Unable to perform operation.\nError: {0}", ex.Message);
            }
            textResults.Text = "Object Type: " + ot.objType + Environment.NewLine +
            ot.message.Replace("\n", Environment.NewLine).ToString();
            Cursor.Current = Cursors.Default;
        }
    }
}
