// Written by Rodney Viana @ Microsoft
// This is a sample from a MSDN blog post at https://blogs.msdn.microsoft.com/rodneyviana/
// License: MIT License
//=================================================

#include <map>
#include <string>
#include <vector>
#pragma once

///
/// Trace levels from https://msdn.microsoft.com/en-us/library/office/ff604025(v=office.14).aspx
///
enum ULSTraceLevel
{
	/// No trace entries will be written        
	None = 0,
	/// This message indicates that a logic check failed that is atypical, or the message returns an unexpected error code.
	Unexpected = 10,
	/// Traces that indicate a problem, but do not need immediate investigation
	Monitorable = 15,
	/// General functional detail, the high priority events that happen in the environment.
	High = 20,
	/// Useful to help support or test teams debug customer or environmental issues.
	Medium = 50,
	/// Useful primarily to help developers debug low-level code failures. Not generally useful to anyone who does not have access to source code or symbols.
	Verbose = 100,
	/// Useful for traces that are likely to be high volume, especially information that is not needed for all debugging scenarios.
	VerboseEx = 200
};

class SPCategories
{
public:
	static std::map<int, std::string> catMap;
	SPCategories();
	~SPCategories();

	static void EnsureMap();
	
	static bool GetAreaName(int Category, std::string& Area, std::string& Product);

	static bool ContainsAreaName(int Category, std::string PartialName);

	static std::map<int,int> GetListAreaName(std::string PartialName);

	static std::string GetSevLevel(int SevId);
};

