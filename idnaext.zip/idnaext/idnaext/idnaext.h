//================================================
// Written by Rodney Viana @ Microsoft
// This is a sample from a MSDN blog post at https://blogs.msdn.microsoft.com/rodneyviana/
// License: MIT License
//=================================================

#pragma once

#include <wrl\client.h>
#include <DbgModel.h>
#include <engextcpp.hpp>
#include <string>
#include <vector>
#include <memory>
#include <regex>
#include <map>
#include <atlbase.h>


//
// From sdk wdm.h
// Define system time structure.
//

typedef struct _KSYSTEM_TIME {
	ULONG LowPart;
	LONG High1Time;
	LONG High2Time;
} KSYSTEM_TIME, *PKSYSTEM_TIME;

//
// Adapted from ntextapi.h
//
struct KUSER_SHARED_DATA_MINI {

	//
	// Current low 32-bit of tick count and tick count multiplier.
	//
	// N.B. The tick count is updated each time the clock ticks.
	//

	ULONG TickCountLowDeprecated;
	ULONG TickCountMultiplier;

	//
	// Current 64-bit interrupt time in 100ns units.
	//

	volatile KSYSTEM_TIME InterruptTime;

	//
	// Current 64-bit system time in 100ns units.
	//

	volatile KSYSTEM_TIME SystemTime;

	//
	// Current 64-bit time zone bias.
	//

	volatile KSYSTEM_TIME TimeZoneBias;

	//
	// Support image magic number range for the host system.
	//
	// N.B. This is an inclusive range.
	//

	USHORT ImageNumberLow;
	USHORT ImageNumberHigh;

	//
	// Copy of system root in unicode.
	//

	WCHAR NtSystemRoot[260];

	//
	// Maximum stack trace depth if tracing enabled.
	//

	ULONG MaxStackTraceDepth;

	//
	// Crypto exponent value.
	//

	ULONG CryptoExponent;

	//
	// Time zone ID.
	//

	ULONG TimeZoneId;
	ULONG LargePageMinimum;

	//
	// This value controls the AIT Sampling rate.
	//

	ULONG AitSamplingValue;

	//
	// This value controls switchback processing.
	//

	ULONG AppCompatFlag;

	//
	// Current Kernel Root RNG state seed version
	//

	ULONGLONG RNGSeedVersion;

	//
	// This value controls assertion failure handling.
	//

	ULONG GlobalValidationRunlevel;

	volatile LONG TimeZoneBiasStamp;

	//
	// Reserved (available for reuse).
	//
};

#pragma region Time
// Const below are adapted from https://referencesource.microsoft.com/#mscorlib/system/datetime.cs,0fcf4825e44c2d04
const UINT64 TicksPerMillisecond = 10000;
const UINT64 TicksPerSecond = TicksPerMillisecond * 1000;
const UINT64 TicksPerMinute = TicksPerSecond * 60;
const UINT64 TicksPerHour = TicksPerMinute * 60;
const UINT64 TicksPerDay = TicksPerHour * 24;

// Number of milliseconds per time unit
const UINT64 MillisPerSecond = 1000;
const UINT64 MillisPerMinute = MillisPerSecond * 60;
const UINT64 MillisPerHour = MillisPerMinute * 60;
const UINT64 MillisPerDay = MillisPerHour * 24;

// Number of days in a non-leap year
const int DaysPerYear = 365;

// Number of days in 4 years
const int DaysPer4Years = DaysPerYear * 4 + 1;

// Number of days in 100 years
const int DaysPer100Years = DaysPer4Years * 25 - 1;

// Number of days in 400 years
const int DaysPer400Years = DaysPer100Years * 4 + 1;

// Number of days from 1/1/0001 to 12/31/1600
const int DaysTo1601 = DaysPer400Years * 4;

// Number of days from 1/1/0001 to 12/30/1899
const int DaysTo1899 = DaysPer400Years * 4 + DaysPer100Years * 3 - 367;

// Number of days from 1/1/0001 to 12/31/9999
const int DaysTo10000 = DaysPer400Years * 25 - 366;

const UINT64 MinTicks = 0;
const UINT64 MaxTicks = DaysTo10000 * TicksPerDay - 1;
const UINT64 MaxMillis = (INT64)DaysTo10000 * MillisPerDay;

const UINT64  FileTimeOffset = DaysTo1601 * TicksPerDay;
const UINT64  DoubleDateOffset = DaysTo1899 * TicksPerDay;
const ULONG64 TicksMask = 0x3FFFFFFFFFFFFFFF;
extern int DaysToMonth365[13];
extern int DaysToMonth366[13];
// End Time Constants from DateTime.cs

const UINT64 Ticksfrom1970 = 621355968000000000;

#pragma endregion

#define MAX_BUFFER 1024

#define MAX_MTNAME 1024
extern wchar_t NameBuffer[MAX_MTNAME];

extern wchar_t Buffer[MAX_BUFFER];

#define CLRDATA_ADDRESS UINT64

#define GetVar(x) envVars.find(x) == envVars.end() ? L"" : envVars[x]

#define REQ_IF(_If, _Member) \
    if (!m_Client || (Status = m_Client->QueryInterface(__uuidof(_If), \
                                        (PVOID*)&_Member)) != S_OK) \
    { \
		Out("Unable to get _If Interface"); \
        return; \
    }


#define TryToAquire(_x, error) \
    if(FAILED(_x)); \
    { \
      Out("Error during _x \n"); \
      return; \
    }

using namespace std;

extern std::map<std::wstring, std::wstring> varsDict;
typedef std::map<std::wstring, std::wstring>::const_iterator EnvVarsIterator;

const char symbols[] = "abcdefghijklmnopqrstuvwxyz0123456789****************************";

bool IsValidMemory(CLRDATA_ADDRESS Address, INT64 Size = 0);
BOOL IsInterrupted();

std::wstring tickstodatetime(UINT64 Ticks);

class EXT_CLASS : public ExtExtension
{
private:

	bool ReadSharedData(KUSER_SHARED_DATA_MINI& SharedData)
	{
		ZeroMemory(&SharedData, sizeof(SharedData));
		UINT64 sharedData = 0;
		ULONG size = 0;
		HRESULT hr = m_Data->ReadDebuggerData(DEBUG_DATA_SharedUserData, &sharedData, sizeof(sharedData), &size);
		if (hr != S_OK)
			return false;
		hr = m_Data->ReadVirtual(sharedData, &SharedData, sizeof(SharedData), &size);
		if (hr != S_OK)
			return false;
		return true;
	}
public:

	EXT_COMMAND_METHOD(apppool);
	EXT_COMMAND_METHOD(netversion);
	EXT_COMMAND_METHOD(idnauls);
	EXT_COMMAND_METHOD(timer);
	EXT_COMMAND_METHOD(set);


	bool GetTime(SYSTEMTIME& FormattedTime, bool IsTimeLocal = false)
	{
		KUSER_SHARED_DATA_MINI sharedData;

		ZeroMemory(&FormattedTime, sizeof(FormattedTime));

		if (!ReadSharedData(sharedData))
		{
			return false;

		}
		
		if (IsTimeLocal)
		{
			INT64 *time1 = (INT64*)&(sharedData.SystemTime);
			INT64 *time2 = (INT64*)&(sharedData.TimeZoneBias);
			*time1 -= *time2;
		}
		FILETIME time;
		time.dwLowDateTime = sharedData.SystemTime.LowPart;
		time.dwHighDateTime = sharedData.SystemTime.High1Time;
		::FileTimeToSystemTime(&time, &FormattedTime);
		return true;
	}
	UINT64 Timer;
	UINT64 GetElapsedTime()
	{
		UINT64 now = Timer;
		Timer = GetTickCount64();
		return Timer - now;
	}

	void ShowTimer()
	{
		NameBuffer[0] = L'\0';

		GetTimeFormatEx(LOCALE_NAME_USER_DEFAULT, TIME_FORCE24HOURFORMAT, NULL, NULL, NameBuffer, MAX_MTNAME);
		Out("New Timer at: %S\n", NameBuffer);

		bool isFirst = (0 == Timer);
		UINT64 elapsed = GetElapsedTime();
		if (!isFirst)
		{
			Out("Last timer took %f seconds\n", (float)((float)elapsed / (float)1000));
		}
	}

	int LetterToIndex(char Chr)
	{
		if (Chr >= 'a' && Chr <= 'z')
			return Chr - 'a';
		if (Chr >= L'0' && Chr <= '9')
			return Chr - '0' + ('z' - 'a') + 1;
		// should not get here
		return -1;
	}

	std::string TagToStr(unsigned int Tag)
	{
		std::string TagStr;
		if ((Tag >> 24) < 36) // Non ascii char means it is 5
		{
			// compacted to 6-bits - each part 
			TagStr += symbols[(Tag >> 24) & 0x3f];
			TagStr += symbols[(Tag >> 18) & 0x3f];
			TagStr += symbols[(Tag >> 12) & 0x3f];
			TagStr += symbols[(Tag >> 6) & 0x3f];
			TagStr += symbols[Tag & 0x3f];
		}
		else
		{
			TagStr += (char)((Tag >> 24) & 0x7F);
			TagStr += (char)((Tag >> 16) & 0x7F);
			TagStr += (char)((Tag >> 8) & 0x7F);
			TagStr += (char)((Tag) & 0x7F);
		}

		return TagStr;
	}

	unsigned int StrToTag(std::string StrTag)
	{

		if (StrTag.size() == 4)
		{
			return (StrTag[0] << 24) + (StrTag[1] << 16) + (StrTag[2] << 8) + (StrTag[3]);
		}

		if (StrTag.size() == 5)
		{
			int sum = 0;
			for (int i = 0; i <= 4; i++)
			{
				sum = sum << 6;
				sum += LetterToIndex(StrTag[i]);


			}

			return sum; 
		}

		return 0; // if it is a bad string, returns 0 which can be interpreted as invalid
	}

	static std::string Execute(const std::string &Command)
	{
		std::auto_ptr<ExtCaptureOutputA> execContext(new ExtCaptureOutputA());

		execContext->Execute(Command.c_str());

		std::string retStr;
		if (execContext->m_Text)
			retStr.assign(execContext->m_Text);

		return retStr;

	}

	static std::wstring ReadTypedUnicode(CLRDATA_ADDRESS Address)
	{

		USHORT realSize;
		ExtRemoteData size(Address, sizeof(realSize));
		if (!size.m_ValidOffset)
		{
			return L"";
		}

		ExtRemoteData stringPtr(Address + 8, g_ExtInstancePtr->m_PtrSize);
		ZeroMemory(NameBuffer, sizeof(NameBuffer));

		realSize = size.GetUshort();

		if (realSize > (MAX_MTNAME - 2))
			realSize = MAX_MTNAME - 2;

		ULONG64 Addr = stringPtr.GetPtr();

		ExtRemoteData buffer(Addr, realSize);
		if (!buffer.m_ValidOffset)
		{
			return L"";
		}

		buffer.ReadBuffer(NameBuffer, realSize, false);


		std::wstring uniStr((wchar_t*)NameBuffer);

		return uniStr;

	}
	static std::wstring GetProcessName()
	{
		ExtRemoteTyped peb("(ntdll!_PEB*)@$extin", g_ExtInstancePtr->EvalExprU64("@$peb"));
		ExtRemoteTyped processName = peb.Field("ProcessParameters.ImagePathName");
		return ReadTypedUnicode(processName.m_Offset);


	}

	static std::wstring GetProcessCommandLine()
	{
		ExtRemoteTyped peb("(ntdll!_PEB*)@$extin", g_ExtInstancePtr->EvalExprU64("@$peb"));
		ExtRemoteTyped cmdLine = peb.Field("ProcessParameters.CommandLine");
		return ReadTypedUnicode(cmdLine.m_Offset);
	}


	static std::map<std::wstring, std::wstring> GetProcessEnvVar(bool EnableCache = true)
	{
		if (EnableCache && varsDict.size() > 0)
		{
			return varsDict;
		}

		if (!EnableCache)
		{
			varsDict.clear();
		}

		ExtRemoteTyped peb("(ntdll!_PEB*)@$extin", g_ExtInstancePtr->EvalExprU64("@$peb"));
		ExtRemoteTyped envVars = peb.Field("ProcessParameters.Environment");
		ExtRemoteTyped size = peb.Field("ProcessParameters.EnvironmentSize");


		if (!size.m_ValidOffset)
		{
			return varsDict;
		}
		UINT64 totalSize = size.GetLong64();


		ExtRemoteData data(envVars.GetPtr(), static_cast<ULONG>(totalSize));
		if (!data.m_ValidOffset)
		{
			return varsDict;
		}
		byte *buffer = (byte*)calloc(totalSize + 4, sizeof(byte));
		data.ReadBuffer(buffer, static_cast<ULONG>(totalSize), true);

		for (wchar_t* strArray = (wchar_t*)buffer; L'\0' != *strArray; strArray += lstrlenW(strArray) + 1)
		{
			std::wstring str(strArray);
			if (str.find_first_of(L"=") != std::wstring::npos)
				varsDict.emplace(str.substr(0, str.find_first_of(L"=")), str.substr(str.find_first_of(L"=") + 1));
		}

		free(buffer);

		return varsDict;
	}

	static std::wstring GetProcessAccount()
	{
		auto envVars = GetProcessEnvVar();
		auto userName = GetVar(L"USERNAME");
		auto domainName = GetVar(L"USERDOMAIN");
		auto computerName = GetVar(L"COMPUTERNAME");

		if (domainName.size() == 0)
		{
			domainName = computerName;
		}

		if (domainName.size() != 0)
		{
			domainName.append(L"\\");
		}

		return domainName + userName;
	}
};