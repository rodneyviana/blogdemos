
// ImpersonationDlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "strsafe.h"
#include "Sddl.h"


// CImpersonationDlg dialog
class CImpersonationDlg : public CDialog
{
// Construction
public:
	CImpersonationDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_IMPERSONATION_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CEdit textUserName;
	CEdit textPassword;
	CEdit textDomain;
	CEdit textSID;
	afx_msg void OnEnUpdateEditUsername();
	CButton btnSetThread;
	CButton btnSetProcess;
	afx_msg void OnBnClickedButtonThreadget();
	void CImpersonationDlg::PrintError(LPTSTR lpszFunction);
	void FillUserInformationFromToken(HANDLE Token);
	afx_msg void OnBnClickedButtonProcessget();
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButtonThreadset();
	afx_msg void OnBnClickedButtonProcessset();
	void ClearFields();
	afx_msg void OnBnClickedReverttoself();
	CButton btnRevertToSelf;
	CButton chkInteractive;
	afx_msg void OnBnClickedButtonImpersonate();
};
