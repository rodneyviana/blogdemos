
// ImpersonationDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Impersonation.h"
#include "ImpersonationDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CImpersonationDlg dialog




CImpersonationDlg::CImpersonationDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CImpersonationDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CImpersonationDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_USERNAME, textUserName);
	DDX_Control(pDX, IDC_EDIT_PASSWORD, textPassword);
	DDX_Control(pDX, IDC_EDIT_DOMAIN, textDomain);
	DDX_Control(pDX, IDC_EDIT_SID, textSID);
	DDX_Control(pDX, IDC_BUTTON_PROCESSSET, btnSetProcess);
	DDX_Control(pDX, IDC_REVERTTOSELF, btnRevertToSelf);
	DDX_Control(pDX, IDC_CHECK_INTERACTIVE, chkInteractive);
}

BEGIN_MESSAGE_MAP(CImpersonationDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_EN_UPDATE(IDC_EDIT_USERNAME, &CImpersonationDlg::OnEnUpdateEditUsername)
	ON_EN_UPDATE(IDC_EDIT_PASSWORD, &CImpersonationDlg::OnEnUpdateEditUsername)
	ON_EN_UPDATE(IDC_EDIT_DOMAIN, &CImpersonationDlg::OnEnUpdateEditUsername)
	ON_EN_UPDATE(IDC_EDIT_SID, &CImpersonationDlg::OnEnUpdateEditUsername)

	ON_BN_CLICKED(IDC_BUTTON_PROCESSGET, &CImpersonationDlg::OnBnClickedButtonProcessget)
	ON_BN_CLICKED(IDC_BUTTON_THREADGET, &CImpersonationDlg::OnBnClickedButtonThreadget)

	ON_BN_CLICKED(IDC_BUTTON4, &CImpersonationDlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON_PROCESSSET, &CImpersonationDlg::OnBnClickedButtonProcessset)
	ON_BN_CLICKED(IDC_REVERTTOSELF, &CImpersonationDlg::OnBnClickedReverttoself)
	ON_BN_CLICKED(IDC_BUTTON_IMPERSONATE, &CImpersonationDlg::OnBnClickedButtonImpersonate)
END_MESSAGE_MAP()


// CImpersonationDlg message handlers

BOOL CImpersonationDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CImpersonationDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CImpersonationDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CImpersonationDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CImpersonationDlg::OnEnUpdateEditUsername()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_UPDATE flag ORed into the lParam mask.
	btnSetProcess.EnableWindow();
	// TODO:  Add your control notification handler code here
}

// Print System Error adapted from http://msdn.microsoft.com/en-us/library/ms680582(VS.85).aspx
void CImpersonationDlg::PrintError(LPTSTR lpszFunction) 
{ 
    // Retrieve the system error message for the last-error code

    LPVOID lpMsgBuf;
    LPVOID lpDisplayBuf;
    DWORD dw = GetLastError(); 

    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPTSTR) &lpMsgBuf,
        0, NULL );

    // Display the error message

    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 
        (lstrlen((LPCTSTR)lpMsgBuf) + lstrlen((LPCTSTR)lpszFunction) + 40) * sizeof(TCHAR)); 
    StringCchPrintf((LPTSTR)lpDisplayBuf, 
        LocalSize(lpDisplayBuf) / sizeof(TCHAR),
        TEXT("%s\nFailed with error %d: %s"), 
        lpszFunction, dw, lpMsgBuf); 
    MessageBox((LPCTSTR)lpDisplayBuf, TEXT("Error"), MB_OK); 

    LocalFree(lpMsgBuf);
    LocalFree(lpDisplayBuf);
}



void CImpersonationDlg::OnBnClickedButtonThreadget()
{
	// TODO: Add your control notification handler code here
	HANDLE tokenHandle;
	ClearFields();
	if(!OpenThreadToken(GetCurrentThread(), TOKEN_QUERY, FALSE, &tokenHandle))
	{
		PrintError(L"Unable to get Current Thread Token. Try to impersonate first.");	
		return;
	}
	AfxMessageBox(L"Current Thread Token retrieved successfully");
	FillUserInformationFromToken(tokenHandle);
	CloseHandle(tokenHandle);
}
void CImpersonationDlg::FillUserInformationFromToken(HANDLE Token)
{
	
	TCHAR user[MAX_PATH], domain[MAX_PATH];
	DWORD sizeSID;
	DWORD sizeUser = sizeof(user);
	DWORD sizeDomain = sizeof(domain);

	SID_NAME_USE sidNameUse;
	TOKEN_USER* tokenUser = (TOKEN_USER*)malloc(MAX_PATH);
	TCHAR* sidString;
	if(!GetTokenInformation(Token, TokenUser, tokenUser, MAX_PATH, &sizeSID))
	{
		PrintError(L"Unable to retrieve user info.");
		return;
	} else
	{
		ConvertSidToStringSid(tokenUser->User.Sid, &sidString);
		textSID.SetWindowText(sidString);
		LocalFree(sidString);
	}
	if(!LookupAccountSid(NULL, tokenUser->User.Sid, user, &sizeUser, domain, &sizeDomain, &sidNameUse))
	{
		PrintError(L"Unable to retrieve user infomation (UserName and Domain). Only SID was retrieved");

	} else
	{
		textDomain.SetWindowText(domain);
		textUserName.SetWindowText(user);
		//textPassword.SetWindowText(L"nopassword");
	}
}

void CImpersonationDlg::ClearFields()
{
		textDomain.SetWindowText(L"");
		textUserName.SetWindowText(L"");
		//textPassword.SetWindowText(L"");
		textSID.SetWindowText(L"");
	
}

void CImpersonationDlg::OnBnClickedButtonProcessget()
{
	// TODO: Add your control notification handler code here
	HANDLE tokenHandle;
	ClearFields();
	if(!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &tokenHandle))
	{
		PrintError(L"Unable to get Current Process Token");		
		return;
	} else
	FillUserInformationFromToken(tokenHandle);
	AfxMessageBox(L"Process Token was retrieved successfully");
	if(tokenHandle)
		CloseHandle(tokenHandle);
}

void CImpersonationDlg::OnBnClickedButton4()
{
	// TODO: Add your control notification handler code here
	SHELLEXECUTEINFO sei = { sizeof(SHELLEXECUTEINFO) };
	int argc;
	
	PWSTR *argsv = CommandLineToArgvW(GetCommandLine(), &argc);
	if(argc == 0)
	{
		PrintError(L"Error retrieving path. Elevation was aborted");
		return;
	}


	// Get Process Full Path
	sei.lpFile = (LPCWSTR)argsv[0];

	// Ask for privileges elevation.
	sei.lpVerb = _T("runas");

	sei.nShow = SW_SHOWNORMAL;
	bool closeWindow = true;	
	if(!ShellExecuteEx(&sei))
	{
		PrintError(L"Unable to elevate privileges");
		closeWindow = false;
	}
	HeapFree(GetProcessHeap(), 0, argsv);
	if(closeWindow)
	{
		this->CloseWindow();
	}
}

void CImpersonationDlg::OnBnClickedButtonThreadset()
{
	// TODO: Add your control notification handler code here
}

void CImpersonationDlg::OnBnClickedButtonProcessset()
{
	// TODO: Add your control notification handler code here
	HANDLE token;
	TCHAR userName[MAX_PATH], domain[MAX_PATH], password[MAX_PATH];
	textUserName.GetWindowText(userName, sizeof(userName));
	textDomain.GetWindowText(domain, sizeof(domain));
	textPassword.GetWindowText(password, sizeof(password));
	textSID.SetWindowText(L"");


	DWORD logonType = LOGON32_LOGON_NETWORK;
	if(chkInteractive.GetCheck() == BST_CHECKED)
		logonType = LOGON32_LOGON_INTERACTIVE;
	if(!LogonUser(userName, domain, password, logonType, LOGON32_PROVIDER_DEFAULT, &token))
	{
		PrintError(L"Unable to logon with user credential.");
	} else
	{
		if(!ImpersonateLoggedOnUser(token))
		{
			PrintError(L"Unable to impersonate credential.");
		} else
		{
			AfxMessageBox(L"Impersonation was sucessful. You may want to Impersonate Self now.");
			btnRevertToSelf.EnableWindow();
			ClearFields();
			FillUserInformationFromToken(token);

		}
	}
	if(token)
		CloseHandle(token);
}


void CImpersonationDlg::OnBnClickedReverttoself()
{
	// TODO: Add your control notification handler code here
	// TODO: Add your control notification handler code here
	if(!RevertToSelf())
	{
		PrintError(L"Unable to revert to self.");
	} else
	{
		AfxMessageBox(L"Revert to Self was successful.");
	}

}

void CImpersonationDlg::OnBnClickedButtonImpersonate()
{
	// TODO: Add your control notification handler code here
	HANDLE tokenHandle;
	ClearFields();
	if(!OpenProcessToken(GetCurrentProcess(), TOKEN_ALL_ACCESS, &tokenHandle))
	{
		PrintError(L"Unable to get Current Process Token");		
		return;
	}
	if(!ImpersonateLoggedOnUser(tokenHandle))
	{
		PrintError(L"Unable to impersonate credential. Try 'Interactive Logon' instead.");
	} else
	{
		AfxMessageBox(L"Impersonation from Process Token was sucessful");
		btnRevertToSelf.EnableWindow();
		ClearFields();
		FillUserInformationFromToken(tokenHandle);

	}
	if(tokenHandle)
		CloseHandle(tokenHandle);

}
