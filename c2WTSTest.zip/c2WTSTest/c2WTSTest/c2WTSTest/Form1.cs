﻿/*
 * 
 *  c2WTSTest 
 *  This Application is provided 'AS IS' with NEITHER explicit NOR implicit waranty
 *  You have to agree with this license to use this sample: http://rodneyviana.codeplex.com/license
 * 
 *  This application tests various aspects of Claims to Windows NT Token Service.
 *  The resulting report can help System Administrators and Support Engineers to
 *  identify problems in c2WTS service
 * 
 * 
 */


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.ServiceProcess;
using System.Management;
using Microsoft.IdentityModel.WindowsTokenService;
using Microsoft.IdentityModel.Claims;
using System.Security.Principal;
using System.Threading;
using System.Runtime.InteropServices;
using System.Runtime;
using Microsoft.Win32.SafeHandles;
using System.Runtime.ConstrainedExecution;
using System.Security.Permissions;
using System.IO;
using System.Xml;



namespace c2WTSTest
{


    public partial class Form1 : Form
    {
        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        public static extern bool LogonUser(String lpszUsername, String lpszDomain, String lpszPassword,
            int dwLogonType, int dwLogonProvider, out SafeTokenHandle phToken);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        public extern static bool CloseHandle(IntPtr handle);

        public IntPtr phToken = IntPtr.Zero;
        public Form1()
        {
            InitializeComponent();
            txtLogin.Text = Environment.UserDomainName + @"\" + Environment.UserName;
            txtPassword.Enabled = false;
            GetService();
            string path = GetServiceWebConfig();
            //c2WTS.Container.Components;
        }

        private static bool IsServiceRunning()
        {
            if (c2WTS == null) return false;

            return (c2WTS.Status == ServiceControllerStatus.Running);
        }

        private static string GetServiceWebConfig()
        {
            string temp = "";
            temp = GetPathOfService();
            if (String.IsNullOrEmpty(temp)) return "";
            return temp + ".config";

        }
        private static ServiceController c2WTS = null;


        private static bool DependsOnCryptSvc()
        {
            if (c2WTS == null) return false;
            if (c2WTS.DependentServices.Count() != 1) return false;
            if (c2WTS.DependentServices[0].ServiceName.ToLower() == "cryptsvc") return true;
            return false;
            
        }


        private static string GetPropOfService(string PropertyName)
        {
            if (c2WTS == null) return "";
            try
            {
                WqlObjectQuery q = new WqlObjectQuery("SELECT * FROM Win32_Service WHERE Name = 'c2wts'");
                ManagementObjectCollection objs = new ManagementObjectSearcher(q).Get();
                if (objs.Count != 1) return "";
                foreach (ManagementObject obj in objs)
                {
                    return obj.Properties[PropertyName].Value.ToString();
                }
            }
            catch (Exception ex)
            {
                return "**** Error: " + ex.Message;
            }
            return "";

        }

        private static string GetPathOfService()
        {
            
            if (c2WTS == null) return "";
            return GetPropOfService("PathName").Replace("\"", ""); // Remove double quotes
        }

        private static string GetServiceLogon()
        {

            if (c2WTS == null) return "";
            string procId = GetPropOfService("ProcessId");
            if (String.IsNullOrEmpty(procId) && procId[0] == '*') return procId;

            WqlObjectQuery q = new WqlObjectQuery(
                String.Format("SELECT * FROM Win32_Process WHERE ProcessId = {0}", procId));
            ManagementObjectCollection objs = new ManagementObjectSearcher(q).Get();

            if (objs.Count != 1) return "";

            object[] pars = new object[2] { "", ""};
            ;

            //ManagementBaseObject objParams;
            

            foreach (ManagementObject obj in objs)
            {
                
                object objx = obj.InvokeMethod("GetOwner", pars);
                UInt32 i = (UInt32)objx;
                switch (i)
                {
                    case 0:
                        return pars[0] + "\\" + pars[1];
                    case 2:
                        return "*** Access Denied ***";
                    case 3:
                        return "*** Insufficient Privilege ***";
                    default:
                        return "*** Unknown Error ***";

                }

            }


            return "";
        }


        private static bool GetService()
        {


            ServiceController[] services = ServiceController.GetServices();

            foreach (ServiceController service in services)
            {
                if (service.ServiceName.ToLower() == "c2wts")
                {
                    c2WTS = service;
                    return true;
                }
            }

            return false;
        }
        const int LOGON32_PROVIDER_DEFAULT = 0;
        //This parameter causes LogonUser to create a primary token.
        const int LOGON32_LOGON_INTERACTIVE = 2;
        SafeTokenHandle token;

        static List<string> GetAccessList(string xmlText)
        {
            List<string> ids = new List<string>();


            try
            {
                XmlDocument xml = new XmlDocument();
                xml.LoadXml(xmlText);

                XmlNodeList nodes = xml.SelectNodes("/configuration/windowsTokenService/allowedCallers/add");
                foreach (XmlNode node in nodes)
                {
                    XmlAttribute attr = node.Attributes["value"];
                    if (attr != null)
                    {
                        ids.Add(attr.Value);
                    }

                }
            }
            catch (Exception ex)
            {
                ids.Add("**** Error in config file: " + ex.Message);
            }

            return ids;

        }


        static string GetTextFile(string FilePath)
        {
            string temp = null;

            try
            {
                StreamReader file = new StreamReader(FilePath);
                temp = file.ReadToEnd();
            }
            catch (Exception ex)
            {
                temp += String.Format("**** ERROR READING FILE {0} - {1} ****", FilePath, ex.Message);
            }


            return temp;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Get the current identity and extract the UPN claim.
            AppDomain.CurrentDomain.SetPrincipalPolicy(PrincipalPolicy.WindowsPrincipal);
            //bool x=Thread.CurrentPrincipal.Identity.IsAuthenticated;
            WindowsClaimsIdentity id = WindowsClaimsIdentity.GetCurrent();
            //IIdentity identity = WindowsIdentity.GetCurrent(); 
            //IClaimsIdentity identity = (IClaimsIdentity)user;
            //
            IClaimsIdentity identity = (IClaimsIdentity)id;
            string upn = null;
            string acct = "";
            foreach (Claim claim in identity.Claims)
            {
                Debug.WriteLine(claim.ClaimType + "=" + claim.Value, "Claims");
                if (StringComparer.Ordinal.Equals(ClaimTypes.Upn, claim.ClaimType))
                {
                    upn = claim.Value;
                    break;
                }

                if (StringComparer.Ordinal.Equals(ClaimTypes.Name, claim.ClaimType))
                {
                    acct = claim.Value;
                }
            }
            string[] parts = acct.Split('\\');

            if (parts.Count() == 2)
            {
                upn = parts[1] + "@" + parts[0];
            }
            Debug.WriteLine(ClaimTypes.Upn, "Upn Type");
            if(upn != null) txtUPN.Text = upn;


            
        }

        private void txtLogin_TextChanged(object sender, EventArgs e)
        {
            if (!txtPassword.Enabled)
            {
                txtPassword.Enabled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!txtUPN.Text.Contains("@"))
            {
                MessageBox.Show("Invalid Upn");
                return;
            }
            txtResult.Clear();
            List<string> ids = new List<string>();

            txtResult.AppendText(String.Format("Testing Service c2WTS" + Environment.NewLine));
            if (!GetService())
            {
                txtResult.AppendText(String.Format("*** Fatal Error: Service is not installed" + Environment.NewLine));
                txtResult.AppendText(String.Format("*** Aborting ***" + Environment.NewLine));

                return;
            }
                
            txtResult.AppendText(String.Format(" +- Service c2WTS found" + Environment.NewLine));
            if (IsServiceRunning())
            {
                txtResult.AppendText(String.Format(" +- Service c2WTS is running" + Environment.NewLine));
            }
            else
            {
                txtResult.AppendText(String.Format(" +- ERROR: Service c2WTS is NOT running. See http://support.microsoft.com/kb/2512597" + Environment.NewLine));
                txtResult.AppendText(String.Format("*** Aborting ***" + Environment.NewLine));
                return;
            }

            string appPath = GetPathOfService();
            txtResult.AppendText(String.Format(" +- Path of service: {0}" + Environment.NewLine, appPath));
            string configPath = GetServiceWebConfig();
            txtResult.AppendText(String.Format(" +- Config File: {0}" + Environment.NewLine, configPath));
            string srvLogin = GetServiceLogon();
            txtResult.AppendText(String.Format(" +- Service Logon: {0}" + Environment.NewLine, srvLogin));
            if(!String.IsNullOrEmpty(srvLogin) && srvLogin != "SYSTEM\\NT AUTHORITY")
                txtResult.AppendText(String.Format("*** Service MUST BE 'SYSTEM\\NT AUTHORITY' (for SharePoint it is ok to be different) ***" + Environment.NewLine));

            //SYSTEM\NT AUTHORITY

            txtResult.AppendText(String.Format("----- start of config file ----" + Environment.NewLine));
            string configText = GetTextFile(configPath);
            txtResult.AppendText(configText + Environment.NewLine);
            txtResult.AppendText(String.Format("-----  end of config file  ----" + Environment.NewLine));


            txtResult.AppendText(String.Format("Retrieving security groups/users allowed to use the service from config file" + Environment.NewLine));
            if (configText.TrimStart()[0] != '<')
            {
                
                txtResult.AppendText(String.Format("*** Config File is invalid ****" + Environment.NewLine));

            }
            else
            {
                ids = GetAccessList(configText);
                if (ids.Count == 0)
                {
                    txtResult.AppendText(String.Format(" +- Warning: no users are allowed in the service" + Environment.NewLine));

                }
                else
                {
                    foreach (string str in ids)
                    {
                        txtResult.AppendText(String.Format(" +- {0}" + Environment.NewLine, str));

                    }

                }

            }



            WindowsIdentity newId;
            string[] parts = txtLogin.Text.Split('\\');
            if (token != null) token.Close();

            txtResult.AppendText(String.Format("Trying to login ........." + Environment.NewLine));

            bool returnValue = false;
            try
            {
                returnValue = (txtPassword.Enabled) ? LogonUser(parts[1], parts[0], txtPassword.Text,
                        LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT,
                        out token) : false;
            }
            catch (Exception ex)
            {
                txtResult.AppendText(String.Format("**** Unable to Login as {0} : {1}" + Environment.NewLine, txtLogin.Text, ex.Message));

            }

            if (token != null)
            {
                newId = new WindowsIdentity(token.DangerousGetHandle());
                txtResult.AppendText(String.Format("Using provided credentials to login" + Environment.NewLine));
            }
            else
            {
                newId = WindowsIdentity.GetCurrent();
                txtResult.AppendText(String.Format("Using current Windows Credentials" + Environment.NewLine));

            }
            using (WindowsImpersonationContext impersonatedUser = newId.Impersonate())
            {
                try
                {
                    WindowsIdentity wi = S4UClient.UpnLogon(txtUPN.Text);
                    txtResult.Text += String.Format("c2WTS Service provided a valid Windows Token for: {0}" + Environment.NewLine, wi.Name);
                    Debug.WriteLine(wi.Name, "Impersonating user: "); 

                }
                catch (Exception ex)
                {
                    txtResult.Text += String.Format("***** c2WTS could not provide a valid Windows Token. Reason: {0}\r\n{1}\r\n"+Environment.NewLine, ex.Message, ex.StackTrace);
                }
                //newId.


                string match = ids.Find(
                    delegate(string idItem)
                    {
                        return (idItem.ToUpper() == newId.Name.ToUpper() || Environment.MachineName.ToUpper() + "\\" + idItem.ToUpper() == newId.Name.ToUpper());
                    });
                bool isInGroup = (match != null);


                foreach (IdentityReference idRef in newId.Groups)
                {
                    if (isInGroup) break;
                    
                    IdentityReference idNT = idRef.Translate(Type.GetType("System.Security.Principal.NTAccount"));
                    
                    string group = idNT.Value;
                    string group1 = "";
                    string[] parts1 = group.Split('\\');
                    if (parts1.Count() > 1)
                    {
                        if (parts1[0].ToUpper() == "BUILTIN" || parts1[0].ToUpper() == Environment.MachineName)
                            group1 = parts1[1];
                    }
                    Debug.WriteLine(group, "Group Found: ");
                    match = ids.Find(
                        delegate(string idItem)
                        {
                           return (idItem.ToUpper() == group.ToUpper() || idItem.ToUpper() == group1.ToUpper()) ;
                        });
                    isInGroup = (match != null);
                }
                txtResult.AppendText(String.Format("Now Verifying if user {0} has rights on c2WTS" + Environment.NewLine, newId.Name));

                if (isInGroup)
                {
                    txtResult.AppendText(String.Format(" +- User {1} has access rights per group/user {0}. Other groups will not be checked" + Environment.NewLine, match, newId.Name));
                }
                else
                {
                    txtResult.AppendText(String.Format(" +- User  {0} has no access to the service" + Environment.NewLine, newId.Name));

                }
            }

            txtResult.AppendText(String.Format("*** Analysis Complete ***" + Environment.NewLine));

            if(token != null) token.Close();
            token = null;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AboutBox1 about = new AboutBox1();
            about.ShowDialog();

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                button1.Enabled = true;
                button2.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
                button2.Enabled = false;
                txtResult.Clear();
            }
        }
    }
    public sealed class SafeTokenHandle : SafeHandleZeroOrMinusOneIsInvalid
    {
        private SafeTokenHandle()
            : base(true)
        {
        }

        [DllImport("kernel32.dll")]
        [ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
        
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CloseHandle(IntPtr handle);

        protected override bool ReleaseHandle()
        {
            return CloseHandle(handle);
        }
    }

}
