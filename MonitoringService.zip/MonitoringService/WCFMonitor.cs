﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Dispatcher;

//The code samples are provided AS IS without warranty of any kind. 
// Microsoft disclaims all implied warranties including, without limitation, 
// any implied warranties of merchantability or of fitness for a particular purpose. 

/* 

The entire risk arising out of the use or performance of the sample scripts and documentation remains with you. 
In no event shall Microsoft, its authors, or anyone else involved in the creation, production, or delivery of the scripts 
be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use of or inability to use the sample scripts 
or documentation, even if Microsoft has been advised of the possibility of such damages. 

*/ 


namespace Microsoft.Sample.MonitoringService
{

    /// <summary>
    /// Interface with WCF Runtime values operations
    /// </summary>
    /// <remarks>More details in http://blogs.msdn.com/rodneyviana</remarks>
    [ServiceContract]
    public interface IWCFMonitor
    {
        [OperationContract]
        string GetProcessInfo();
        [OperationContract]
        ProcessInfoData GetProcessObjInfo();
    }

    /// <summary>
    /// Contains the implementation of WCF Monitoring
    /// </summary>
    /// <remarks>More details in http://blogs.msdn.com/rodneyviana</remarks>
    public class WCFMonitor: IWCFMonitor
    {
        /// <summary>
        /// Return a string with WCF Runtime values
        /// </summary>
        public string GetProcessInfo()
        {
            ProcessInfoData pi = new ProcessInfoData(OperationContext.Current, OperationContext.Current.Host);
            return String.Format("Process Name: {0}{10}GC Mode: {1}{10}Bitness: {2}{10}Max Calls: {3}{10}Max Sessions: {4}{10}Calls: {5}{10}Sessions: {6}{10}User Name: {7}{10}Auth Type: {8}{10}LastError: {9}{10}",
                pi.ProcessName,
                pi.GCMode,
                pi.Bitness,
                pi.MaxCalls,
                pi.MaxSessions,
                pi.Calls,
                pi.Sessions,
                pi.UserName,
                pi.AuthType,
                pi.LastError,
                Environment.NewLine);
        }

        /// <summary>
        /// Return a structure with fields containing WCF Runtime values
        /// </summary>
        public ProcessInfoData GetProcessObjInfo()
        {
            ProcessInfoData pi = new ProcessInfoData(OperationContext.Current, OperationContext.Current.Host);
            return pi;
        }
    }

    /// <summary>
    /// It is populated with runtime values
    /// </summary>
    /// <remarks>Structure with WCF Process Info</remarks>
    [DataContract]
    public class ProcessInfoData
    {
        public ProcessInfoData()
        { }
        protected FieldInfo GetField(Type type, string FieldName)
        {
            return type.GetField(FieldName, BindingFlags.Instance | BindingFlags.NonPublic);
        }

        protected ServiceHostBase host = null;

        private string lastError = null;

        [DataMember]
        public string LastError
        {
            get { return lastError; }
            set { lastError = value; }
        }

        [DataMember]
        public bool IsError
        {
            get
            {
                return !String.IsNullOrEmpty(LastError);
            }
            set { }
        }

        private int maxCalls;

        [DataMember]
        public int MaxCalls
        {
            get { return maxCalls; }
            set { maxCalls = value; }
        }

        private int maxSessions;

        [DataMember]
        public int MaxSessions
        {
            get { return maxSessions; }
            set { maxSessions = value; }
        }

        private int maxInstances;

        [DataMember]
        public int MaxInstances
        {
            get { return maxInstances; }
            set { maxInstances = value; }
        }

        private int calls;

        [DataMember]
        public int Calls
        {
            get { return calls; }
            set { calls = value; }
        }

        private int sessions;

        [DataMember]
        public int Sessions
        {
            get { return sessions; }
            set { sessions = value; }
        }

        private string userName;

        [DataMember]
        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }

        private string authType;

        [DataMember]
        public string AuthType
        {
            get { return authType; }
            set { authType = value; }
        }

        internal ProcessInfoData(OperationContext Context, ServiceHostBase Host)
        {
            if (Context == null)
            {
                lastError = "FATALERROR: Context cannot be null (ProcessInfo)";
                return;
            }
            if (Host == null)
            {
                lastError = "FATALERROR: Context cannot be null (ProcessInfo)";
                return;
            }
            maxCalls = 0;
            maxInstances = 0;
            calls = 0;
            sessions = 0;
            ServiceHostBase host = Host;
            
            try
            {
                if (Context.ServiceSecurityContext != null)
                    userName = Context.ServiceSecurityContext.PrimaryIdentity.Name;
                else
                    userName = "Anonymous";
            }
            catch (Exception ex)
            {
                userName = "Anonymous/Unknown";
                lastError = String.Format("NONFATAL: {0} ({1}) (ProcessInfo) (username) ", ex.Message, ex.ToString());
            }
            try
            {
                if (Context.ServiceSecurityContext != null)
                    authType = Context.ServiceSecurityContext.PrimaryIdentity.AuthenticationType;
                else
                    authType = "None";

            }
            catch (Exception ex)
            {
                lastError = String.Format("NONFATAL: {0} ({1}) (ProcessInfo) (authentication)", ex.Message, ex.ToString());
            }

            if (host != null)
            {
                foreach (object obj in host.Description.Behaviors)
                {
                    System.ServiceModel.Description.ServiceThrottlingBehavior throttle = obj as System.ServiceModel.Description.ServiceThrottlingBehavior;

                    if (throttle != null)
                    {
                        maxCalls = throttle.MaxConcurrentCalls;
                        maxSessions = throttle.MaxConcurrentSessions;
                        maxInstances = throttle.MaxConcurrentInstances;
                    }
                }



                Type t = typeof(ServiceHostBase);
                FieldInfo fi = GetField(t, "serviceThrottle");
                ServiceThrottle rtThrottle = null;
                if (fi != null)
                {
                    rtThrottle = fi.GetValue(host) as ServiceThrottle;
                    t = typeof(ServiceThrottle);

                    fi = GetField(t, "calls");
                    if (fi != null)
                    {
                        object o = fi.GetValue(rtThrottle);
                        if (o != null)
                        {
                            fi = GetField(o.GetType(), "count");
                            if (fi != null)
                                calls = (int)fi.GetValue(o);
                        }
                    }
                    fi = GetField(t, "sessions");
                    if (fi != null)
                    {
                        object o = fi.GetValue(rtThrottle);
                        if (o != null)
                        {
                            fi = GetField(o.GetType(), "count");
                            if (fi != null)
                                sessions = (int)fi.GetValue(o);
                        }
                    }
                }

            }

        }

        [DataMember]
        public string ProcessName
        {
            get
            {
                return Process.GetCurrentProcess().ProcessName;
            }
            set { }
        }

        [DataMember]
        public string GCMode
        {
            get
            {
                return System.Runtime.GCSettings.IsServerGC ? "Server" : "Workstation";
            }
            set { }
        }

        [DataMember]
        public byte Bitness
        {
            get
            {
                return sizeof(ulong) * 8;

            }
            set { }
        }


    }
}