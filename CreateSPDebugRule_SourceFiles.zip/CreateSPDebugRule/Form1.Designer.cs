﻿namespace CreateSPDebugRule
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.textApp = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textAppPool = new System.Windows.Forms.TextBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textPath = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textMessage = new System.Windows.Forms.TextBox();
            this.textTag = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textCommand = new System.Windows.Forms.TextBox();
            this.checkCommand = new System.Windows.Forms.CheckBox();
            this.checkLogTag = new System.Windows.Forms.CheckBox();
            this.checkStack = new System.Windows.Forms.CheckBox();
            this.checkDump = new System.Windows.Forms.CheckBox();
            this.numericMaxDumps = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.button4 = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericMaxDumps)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.textApp);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.textAppPool);
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Location = new System.Drawing.Point(12, 16);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(868, 146);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Target";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(696, 82);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(128, 36);
            this.button2.TabIndex = 5;
            this.button2.Text = "Select...";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textApp
            // 
            this.textApp.Enabled = false;
            this.textApp.Location = new System.Drawing.Point(215, 85);
            this.textApp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textApp.Name = "textApp";
            this.textApp.Size = new System.Drawing.Size(458, 26);
            this.textApp.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(696, 35);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 36);
            this.button1.TabIndex = 2;
            this.button1.Text = "Select...";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textAppPool
            // 
            this.textAppPool.Enabled = false;
            this.textAppPool.Location = new System.Drawing.Point(215, 38);
            this.textAppPool.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textAppPool.Name = "textAppPool";
            this.textAppPool.Size = new System.Drawing.Size(458, 26);
            this.textAppPool.TabIndex = 1;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(21, 85);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(172, 24);
            this.radioButton2.TabIndex = 3;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Application/Service:";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(21, 38);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(151, 24);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Application Pool:";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            this.radioButton1.Click += new System.EventHandler(this.radioButton1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textPath);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.textMessage);
            this.groupBox2.Controls.Add(this.textTag);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(12, 186);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(867, 182);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Conditions";
            // 
            // textPath
            // 
            this.textPath.Location = new System.Drawing.Point(216, 134);
            this.textPath.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textPath.Name = "textPath";
            this.textPath.Size = new System.Drawing.Size(608, 26);
            this.textPath.TabIndex = 3;
            this.textPath.Text = "C:\\Program Files\\DebugDiag\\Logs\\";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Path for dumps";
            // 
            // textMessage
            // 
            this.textMessage.Location = new System.Drawing.Point(216, 80);
            this.textMessage.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textMessage.Name = "textMessage";
            this.textMessage.Size = new System.Drawing.Size(608, 26);
            this.textMessage.TabIndex = 1;
            // 
            // textTag
            // 
            this.textTag.Location = new System.Drawing.Point(216, 39);
            this.textTag.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textTag.Name = "textTag";
            this.textTag.Size = new System.Drawing.Size(90, 26);
            this.textTag.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(192, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Partial Message (optional)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "ULS Tag (e.g. bz7l)";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textCommand);
            this.groupBox3.Controls.Add(this.checkCommand);
            this.groupBox3.Controls.Add(this.checkLogTag);
            this.groupBox3.Controls.Add(this.checkStack);
            this.groupBox3.Controls.Add(this.checkDump);
            this.groupBox3.Controls.Add(this.numericMaxDumps);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Location = new System.Drawing.Point(14, 386);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Size = new System.Drawing.Size(866, 156);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Options";
            // 
            // textCommand
            // 
            this.textCommand.Location = new System.Drawing.Point(215, 99);
            this.textCommand.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textCommand.Name = "textCommand";
            this.textCommand.Size = new System.Drawing.Size(601, 26);
            this.textCommand.TabIndex = 8;
            this.textCommand.TextChanged += new System.EventHandler(this.textCommand_TextChanged);
            // 
            // checkCommand
            // 
            this.checkCommand.AutoSize = true;
            this.checkCommand.Location = new System.Drawing.Point(21, 99);
            this.checkCommand.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkCommand.Name = "checkCommand";
            this.checkCommand.Size = new System.Drawing.Size(196, 24);
            this.checkCommand.TabIndex = 7;
            this.checkCommand.Text = "Execute this command";
            this.checkCommand.UseVisualStyleBackColor = true;
            // 
            // checkLogTag
            // 
            this.checkLogTag.AutoSize = true;
            this.checkLogTag.Location = new System.Drawing.Point(622, 39);
            this.checkLogTag.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkLogTag.Name = "checkLogTag";
            this.checkLogTag.Size = new System.Drawing.Size(194, 24);
            this.checkLogTag.TabIndex = 6;
            this.checkLogTag.Text = "Log non-matching Tag";
            this.checkLogTag.UseVisualStyleBackColor = true;
            // 
            // checkStack
            // 
            this.checkStack.AutoSize = true;
            this.checkStack.Location = new System.Drawing.Point(465, 39);
            this.checkStack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkStack.Name = "checkStack";
            this.checkStack.Size = new System.Drawing.Size(151, 24);
            this.checkStack.TabIndex = 5;
            this.checkStack.Text = "Log Stack Trace";
            this.checkStack.UseVisualStyleBackColor = true;
            // 
            // checkDump
            // 
            this.checkDump.AutoSize = true;
            this.checkDump.Checked = true;
            this.checkDump.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkDump.Location = new System.Drawing.Point(310, 39);
            this.checkDump.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkDump.Name = "checkDump";
            this.checkDump.Size = new System.Drawing.Size(150, 24);
            this.checkDump.TabIndex = 4;
            this.checkDump.Text = "Generate Dump";
            this.checkDump.UseVisualStyleBackColor = true;
            // 
            // numericMaxDumps
            // 
            this.numericMaxDumps.Location = new System.Drawing.Point(215, 38);
            this.numericMaxDumps.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numericMaxDumps.Name = "numericMaxDumps";
            this.numericMaxDumps.Size = new System.Drawing.Size(66, 26);
            this.numericMaxDumps.TabIndex = 3;
            this.numericMaxDumps.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericMaxDumps.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(172, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Max dumps for this rule";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(227, 550);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(487, 46);
            this.button3.TabIndex = 3;
            this.button3.Text = "Generate Template* ... ";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "ddconfig";
            this.saveFileDialog1.Filter = "DebugDiag Configuration|*.ddconfig|All File|*.*";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(35, 550);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(82, 46);
            this.button4.TabIndex = 4;
            this.button4.Text = "About...";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(268, 614);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(398, 20);
            this.linkLabel1.TabIndex = 5;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "* By using the software you agree with the license (MIT)";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(910, 658);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Create SharePoint Debug Rule Wizard";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericMaxDumps)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textApp;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textAppPool;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textMessage;
        private System.Windows.Forms.TextBox textTag;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox checkStack;
        private System.Windows.Forms.CheckBox checkDump;
        private System.Windows.Forms.NumericUpDown numericMaxDumps;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textCommand;
        private System.Windows.Forms.CheckBox checkCommand;
        private System.Windows.Forms.CheckBox checkLogTag;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.TextBox textPath;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}

