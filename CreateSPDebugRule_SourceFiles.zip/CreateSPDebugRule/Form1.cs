﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CreateSPDebugRule
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            textAppPool.Enabled = radioButton1.Checked;
            textApp.Enabled = !radioButton1.Checked;
            textAppPool.Focus();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            textApp.Enabled = radioButton2.Checked;
            textAppPool.Enabled = radioButton2.Checked;
            textApp.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            radioButton1.Checked = true;
            SelectFile sf = new SelectFile();
            sf.FillWithAppPools();
            sf.ShowDialog();
            if(sf.ProcessName != null)
            {
                textAppPool.Text = sf.ProcessName;

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            radioButton2.Checked = true;
            SelectFile sf = new SelectFile();
            sf.FillWithApplications();
            sf.ShowDialog();
            if (sf.ProcessName != null)
            {
                textApp.Text = sf.ProcessName;

            }
        }

        private void radioButton1_Click(object sender, EventArgs e)
        {

        }

        private void textCommand_TextChanged(object sender, EventArgs e)
        {
            if (textCommand.Text.Length > 0 && !checkCommand.Checked)
                checkCommand.Checked = true;
        }

        private string CommentOrNot(CheckBox Box)
        {
            return Box.Checked ? "" : "' ";
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if(
                (String.IsNullOrEmpty(textAppPool.Text) &&
                String.IsNullOrEmpty(textApp.Text)) ||
                String.IsNullOrEmpty(textTag.Text)
                )
            {
                MessageBox.Show("You need to select a target and a ULS Tag");
                return;
            }

            if(textTag.Text.Length < 4 || textTag.Text.Length > 5)
            {
                MessageBox.Show("ULS Tag size is invalid");
                textTag.Focus();
                return;
            }
            Dictionary<string, string> vars = new Dictionary<string, string>();
            vars["$apppoolname"] = textAppPool.Text;
            vars["$processname"] = textApp.Text;
            vars["$path"] = textPath.Text[textPath.Text.Length - 1] == '\\' ?
                textPath.Text.Substring(0, textPath.Text.Length -1) :
                textPath.Text;
            vars["$maxdump"] = numericMaxDumps.Value.ToString();
            vars["$tag"] = textTag.Text.Trim();
            vars["$message"] = textMessage.Text;
            vars["$nolog"] = CommentOrNot(checkLogTag); // not checked => remark
            vars["$nodump"] = CommentOrNot(checkDump);
            vars["$nostack"] = CommentOrNot(checkStack);
            vars["$nocommand"] = CommentOrNot(checkCommand);
            vars["$command"] = textCommand.Text;

            string template;
            if(String.IsNullOrEmpty(textApp.Text))
            {
                template = Properties.Resources.ruleforapppool;
            } else
            {
                template = Properties.Resources.ruleforprocess;
            }
            foreach(var item in vars)
            {
                template = template.Replace(item.Key, item.Value); // Not beautiful but ok for an stand alone App
            }
            if(saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if (File.Exists(saveFileDialog1.FileName))
                    {
                        // The dialog asks for overwrite confirmation
                        // so, it gets here the file should be erased
                        File.Delete(saveFileDialog1.FileName);
                    }
                    File.AppendAllText(saveFileDialog1.FileName, template);
                    MessageBox.Show("File "+saveFileDialog1.FileName+" was saved", "Sucess");

                } catch(Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error");
                }
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            using (AboutBox1 box = new AboutBox1())
            {
                box.ShowDialog();
            }
        }

        private string linkStr = "https://github.com/rodneyviana/blogdemos/blob/master/LICENSE/";
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(linkStr);
        }
    }
}
