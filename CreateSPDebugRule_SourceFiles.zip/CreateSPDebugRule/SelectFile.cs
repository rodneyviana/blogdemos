﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.DirectoryServices;

namespace CreateSPDebugRule
{
    public partial class SelectFile : Form
    {
        public SelectFile()
        {
            InitializeComponent();
        }

        public void FillWithApplications()
        {

            //var p = Process.GetProcesses();
            var processes =
                from p in Process.GetProcesses()
                orderby p.ProcessName
                select p.ProcessName + ".exe";


            listBox1.DataSource = processes.Distinct().ToList<string>();
            listBox1.Refresh();
            listBox1.Update();

            //MainModule.ModuleName
        }

        public void FillWithAppPools()
        {

            //var p = Process.GetProcesses();

            DirectoryEntries dirEntries = new DirectoryEntry("IIS://localhost/W3SVC/AppPools").Children;
            List<string> entries = new List<string>();
            try
            {
                foreach (DirectoryEntry entry in dirEntries)
                {
                    entries.Add(entry.Name);
                }
            } catch
            {
                MessageBox.Show("It seems IIS is not installed");

            }
            entries.Sort();


            listBox1.DataSource = entries;
            listBox1.Refresh();
            listBox1.Update();

            //MainModule.ModuleName
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private string process = null;

        public string ProcessName
        {
            get
            {
                return process;
            }
        }
        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
            process = (string)listBox1.SelectedItem;
            this.Close();
        }
    }
}
