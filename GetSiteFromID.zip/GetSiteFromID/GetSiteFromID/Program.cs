using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint;



namespace GetSiteFromID
{
    class Program
    {
        static string SidAsString(byte[] Sid)
        {
            StringBuilder sidString = new StringBuilder("0x");
            foreach (byte b in Sid)
            {
                sidString.Append(String.Format("{0:X2}", b));

            }
            return sidString.ToString();
        }

        static void ShowSyntax()
        {
            Console.WriteLine("Usage:");
            Console.WriteLine("\tGetSiteFromID <SiteID> <SID> <Quiet=[0|1]>");
            Console.WriteLine("Where:\n\t<SiteID> is the site GUID");
            Console.WriteLine("\t<SID> is the binary form of the SID");
            Console.WriteLine("\tIf Quiet is 1 than it won't wait for a key ");

            Console.WriteLine("Sample:");
            Console.WriteLine("\tGetSiteFromID 8F13DAB6-B1A3-4B48-B301-0FCC53470222 0x010500000000000515000000A421C393FEED76563B2DB2307B040000 0");

        }
        static void Main(string[] args)
        {
            Console.WriteLine("GetSiteFromID");
            Console.WriteLine("=============");
            Console.WriteLine("Show if a Guid is in a Site");
            Console.WriteLine("Written by Rodney Viana");
            Console.WriteLine("This software is supplied \"AS IS\"");
            Console.WriteLine("You have to agree with the terms in http://www.codeplex.com/rodneyviana/license to use this program");


            if (args.Length < 3)
            {

                ShowSyntax();
                return;
            }
            string siteGuid = args[0];
            string siteSID = args[1];
            string quiet = "0";
            if (args.Length >= 3)
            {
                quiet = args[2];
            }
            using (SPSite site = new SPSite(new Guid(siteGuid)))
            {
                Console.WriteLine(String.Format("Looking for site:{0} SID:{1}", siteGuid, siteSID));
                Console.WriteLine(String.Format("Host={0} Url={1}\nOwner={2}", site.HostName,
                    site.Url, site.Owner.ToString()));
                using (SPWeb web = site.OpenWeb())
                {
                    bool found = false;
                    foreach(SPUser user in web.AllUsers)
                    {
                        if (siteSID == SidAsString(user.RawSid))
                        {
                            found = true;
                            Console.WriteLine("Found {0}:{1}", user.LoginName, user.Sid);
                        }
                    }
                    if (!found)
                    {
                        Console.WriteLine("not found");
                    }
                }
                if (quiet != "1")
                {
                    Console.Write("Press Any Key...");
                    Console.ReadKey();
                }

                

            }
            
        }
    }
}
