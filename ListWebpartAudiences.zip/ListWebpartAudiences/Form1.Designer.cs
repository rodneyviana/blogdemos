﻿namespace ListWebpartAudiences
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.textStatus = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.buttonPopulate2 = new System.Windows.Forms.Button();
            this.comboAudiences2 = new System.Windows.Forms.ComboBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.textURL = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.textGUID = new System.Windows.Forms.MaskedTextBox();
            this.comboAudiences1 = new System.Windows.Forms.ComboBox();
            this.buttonPopulate1 = new System.Windows.Forms.Button();
            this.existsInSSP = new System.Windows.Forms.ToolTip(this.components);
            this.anyGUID = new System.Windows.Forms.ToolTip(this.components);
            this.actionTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textStatus
            // 
            this.textStatus.Location = new System.Drawing.Point(0, 356);
            this.textStatus.Multiline = true;
            this.textStatus.Name = "textStatus";
            this.textStatus.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textStatus.Size = new System.Drawing.Size(599, 352);
            this.textStatus.TabIndex = 6;
            this.textStatus.WordWrap = false;
            this.textStatus.LocationChanged += new System.EventHandler(this.textStatus_LocationChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.radioButton5);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.textURL);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Controls.Add(this.textGUID);
            this.groupBox1.Controls.Add(this.comboAudiences1);
            this.groupBox1.Controls.Add(this.buttonPopulate1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(599, 350);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Settings";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(212, 315);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(174, 17);
            this.checkBox1.TabIndex = 18;
            this.checkBox1.Text = "Verbose output (recommended)";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Enabled = false;
            this.button5.Location = new System.Drawing.Point(98, 310);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(98, 24);
            this.button5.TabIndex = 17;
            this.button5.Tag = "2";
            this.button5.Text = "Make Changes";
            this.actionTip1.SetToolTip(this.button5, "This button will actually perform the changes\r\nif any change is selected. The cha" +
                    "nges will\r\nbe shown in the status box.");
            this.existsInSSP.SetToolTip(this.button5, "\r\n");
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(6, 310);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(86, 24);
            this.button4.TabIndex = 16;
            this.button4.Tag = "1";
            this.button4.Text = "Test Settings";
            this.actionTip1.SetToolTip(this.button4, "This button will show how the changes will be\r\nbut it will not change anything.");
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button1_Click);
            // 
            // radioButton5
            // 
            this.radioButton5.Checked = true;
            this.radioButton5.Location = new System.Drawing.Point(6, 35);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(296, 33);
            this.radioButton5.TabIndex = 13;
            this.radioButton5.TabStop = true;
            this.radioButton5.Tag = "1";
            this.radioButton5.Text = "Look for any missing audience in all webparts.";
            this.anyGUID.SetToolTip(this.radioButton5, "It will look for Audiences in webparts that are\r\nnot present in the associated SS" +
                    "P. That is, all\r\ninvalid audiences (it happens when you restore a\r\ncontent db wi" +
                    "thout the correspondent SSP.");
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.radioButton6);
            this.panel1.Controls.Add(this.radioButton4);
            this.panel1.Controls.Add(this.buttonPopulate2);
            this.panel1.Controls.Add(this.comboAudiences2);
            this.panel1.Controls.Add(this.radioButton3);
            this.panel1.Location = new System.Drawing.Point(3, 160);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(590, 137);
            this.panel1.TabIndex = 12;
            // 
            // radioButton6
            // 
            this.radioButton6.Checked = true;
            this.radioButton6.Location = new System.Drawing.Point(3, 3);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(372, 48);
            this.radioButton6.TabIndex = 15;
            this.radioButton6.TabStop = true;
            this.radioButton6.Tag = "1";
            this.radioButton6.Text = "If found do nothing. I just want to find the webparts with this Audience.";
            this.actionTip1.SetToolTip(this.radioButton6, "This option will only enumerate the webparts\r\ncontaining the audience without cha" +
                    "nging\r\nanything.");
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.Location = new System.Drawing.Point(3, 98);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(424, 26);
            this.radioButton4.TabIndex = 14;
            this.radioButton4.Tag = "3";
            this.radioButton4.Text = "If found remove from the webparts. I will not be using this Audience anymore.";
            this.anyGUID.SetToolTip(this.radioButton4, "If found, the previous audience will be\r\nremoved from the webpart.");
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // buttonPopulate2
            // 
            this.buttonPopulate2.Enabled = false;
            this.buttonPopulate2.Location = new System.Drawing.Point(495, 59);
            this.buttonPopulate2.Name = "buttonPopulate2";
            this.buttonPopulate2.Size = new System.Drawing.Size(86, 24);
            this.buttonPopulate2.TabIndex = 13;
            this.buttonPopulate2.Text = "Populate";
            this.existsInSSP.SetToolTip(this.buttonPopulate2, "This button will populate the control with\r\nexisting Audiences related to the Sit" +
                    "e URL above.\r\n");
            this.buttonPopulate2.UseVisualStyleBackColor = true;
            this.buttonPopulate2.Click += new System.EventHandler(this.buttonPopulate_Click);
            // 
            // comboAudiences2
            // 
            this.comboAudiences2.Enabled = false;
            this.comboAudiences2.FormattingEnabled = true;
            this.comboAudiences2.Location = new System.Drawing.Point(115, 59);
            this.comboAudiences2.Name = "comboAudiences2";
            this.comboAudiences2.Size = new System.Drawing.Size(374, 21);
            this.comboAudiences2.TabIndex = 13;
            // 
            // radioButton3
            // 
            this.radioButton3.Location = new System.Drawing.Point(3, 45);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(110, 47);
            this.radioButton3.TabIndex = 12;
            this.radioButton3.Tag = "2";
            this.radioButton3.Text = "If found replace with this audience:";
            this.existsInSSP.SetToolTip(this.radioButton3, "If found, the previous Audience will be replaced by this existing audience");
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.Location = new System.Drawing.Point(6, 121);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(111, 33);
            this.radioButton2.TabIndex = 11;
            this.radioButton2.Tag = "3";
            this.radioButton2.Text = "Look for this audience ID:";
            this.anyGUID.SetToolTip(this.radioButton2, resources.GetString("radioButton2.ToolTip"));
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // textURL
            // 
            this.textURL.Location = new System.Drawing.Point(122, 9);
            this.textURL.Name = "textURL";
            this.textURL.Size = new System.Drawing.Size(374, 20);
            this.textURL.TabIndex = 3;
            this.textURL.Leave += new System.EventHandler(this.textURL_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Site URL:";
            // 
            // radioButton1
            // 
            this.radioButton1.Location = new System.Drawing.Point(6, 74);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(111, 34);
            this.radioButton1.TabIndex = 10;
            this.radioButton1.TabStop = true;
            this.radioButton1.Tag = "2";
            this.radioButton1.Text = "Look for this existing Audience:";
            this.anyGUID.SetToolTip(this.radioButton1, resources.GetString("radioButton1.ToolTip"));
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // textGUID
            // 
            this.textGUID.Enabled = false;
            this.textGUID.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.textGUID.Location = new System.Drawing.Point(122, 128);
            this.textGUID.Mask = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa";
            this.textGUID.Name = "textGUID";
            this.textGUID.Size = new System.Drawing.Size(373, 20);
            this.textGUID.TabIndex = 9;
            this.textGUID.Text = "00000000000000000000000000000000";
            this.anyGUID.SetToolTip(this.textGUID, resources.GetString("textGUID.ToolTip"));
            this.textGUID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.maskedTextBox1_KeyPress);
            // 
            // comboAudiences1
            // 
            this.comboAudiences1.Enabled = false;
            this.comboAudiences1.FormattingEnabled = true;
            this.comboAudiences1.Location = new System.Drawing.Point(122, 84);
            this.comboAudiences1.Name = "comboAudiences1";
            this.comboAudiences1.Size = new System.Drawing.Size(373, 21);
            this.comboAudiences1.TabIndex = 5;
            this.comboAudiences1.SelectedIndexChanged += new System.EventHandler(this.comboAudiences1_SelectedIndexChanged);
            // 
            // buttonPopulate1
            // 
            this.buttonPopulate1.Enabled = false;
            this.buttonPopulate1.Location = new System.Drawing.Point(501, 84);
            this.buttonPopulate1.Name = "buttonPopulate1";
            this.buttonPopulate1.Size = new System.Drawing.Size(86, 24);
            this.buttonPopulate1.TabIndex = 6;
            this.buttonPopulate1.Text = "Populate";
            this.existsInSSP.SetToolTip(this.buttonPopulate1, resources.GetString("buttonPopulate1.ToolTip"));
            this.buttonPopulate1.UseVisualStyleBackColor = true;
            this.buttonPopulate1.Click += new System.EventHandler(this.buttonPopulate_Click);
            // 
            // existsInSSP
            // 
            this.existsInSSP.IsBalloon = true;
            this.existsInSSP.ToolTipTitle = "Existing Audiences";
            // 
            // anyGUID
            // 
            this.anyGUID.IsBalloon = true;
            this.anyGUID.ToolTipTitle = "Id (GUID) of the Audience";
            // 
            // actionTip1
            // 
            this.actionTip1.IsBalloon = true;
            this.actionTip1.ToolTipTitle = "Action";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(420, 310);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 23);
            this.button1.TabIndex = 20;
            this.button1.Text = "About...";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(599, 706);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textStatus);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Web Part Audiences Tool";
            this.anyGUID.SetToolTip(this, resources.GetString("$this.ToolTip"));
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.ResizeEnd += new System.EventHandler(this.Form1_ResizeEnd);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textStatus;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textURL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonPopulate1;
        private System.Windows.Forms.ComboBox comboAudiences1;
        private System.Windows.Forms.ToolTip existsInSSP;
        private System.Windows.Forms.ToolTip anyGUID;
        private System.Windows.Forms.MaskedTextBox textGUID;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.Button buttonPopulate2;
        private System.Windows.Forms.ComboBox comboAudiences2;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ToolTip actionTip1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button1;
    }
}

