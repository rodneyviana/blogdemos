﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Publishing;
using Microsoft.Office.Server.Audience;
using Microsoft.Office.Server;
using Microsoft.SharePoint.Administration;





namespace ListWebpartAudiences
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            textStatus.Top = 356;
            textURL.Text = "http://" + Environment.MachineName.ToLower();
            textURL.Focus();
            textURL.SelectAll();

        }


        private DataTable results = null;

        private void button1_Click(object sender, EventArgs e)
        {
            string lists = "<Lists ServerTemplate=\"850\" />";
            string viewFields = "<FieldRef Name=\"Title\" /><FieldRef Name=\"FileRef\" /><FieldRef Name=\"CheckoutUser\" />";
            string webs = "<Webs Scope=\"Recursive\" />";
            SPSiteDataQuery siteQuery = new SPSiteDataQuery();
            siteQuery.Lists = lists;
            siteQuery.ViewFields = viewFields;
            siteQuery.Webs = webs;

            bool test = (((sender as System.Windows.Forms.Button)).Tag.ToString() == "1");
            if (!test)
            {
                MessageBox.Show("Modifications are not implemented by design\nYou will need to make the modifications yourself.", "Not Implemented");
                button5.Enabled = false;
            }
            else
            {
                textStatus.Clear();
                textStatus.AppendText("[TEST MODE]: No modifications will be saved. You will have to change manually.\n\n");
            }
            string newAudience = "";
            if (replaceStatus == 2)
            {
                if (comboAudiences2.SelectedIndex > -1)
                {
                    string temp = comboAudiences2.SelectedItem.ToString();
                    if (temp != null && temp.Length > 36)
                        newAudience = temp.Substring(temp.Length - 36);

                }
                else
                {
                    MessageBox.Show("Please select an Audience", "Empty Audience");
                    comboAudiences2.Focus();
                    return;

                }
            }
            int found = 0;
            try
            {
                using (SPSite site = new SPSite(textURL.Text))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        if (results != null) results.Dispose();
                        results = web.GetSiteData(siteQuery);
                        textStatus.AppendText(String.Format("\r\nIt was found {0} webpart Page(s) in site collection {1}\r\n", results.Rows.Count, site.Url));


                        AudienceManager audManager = new AudienceManager(ServerContext.GetContext(site));

                        foreach (DataRow dr in results.Rows)
                        {
                            string path = dr["FileRef"].ToString();
                            path = "/" + path.Substring(path.IndexOf('#') + 1);
                            SPLimitedWebPartManager webPartManager = web.GetLimitedWebPartManager(path, PersonalizationScope.Shared);

                            textStatus.AppendText(String.Format("\r\nFound page {0}{1} ({2} web parts)\r\n", site.Url, path, webPartManager.WebParts.Count));

                            if (webPartManager.WebParts.Count <= 0)
                            {
                                textStatus.AppendText("[TEST MODE]: No modifications will be saved. You will have top change manually.\r\n\r\n");

                            }
                            foreach (System.Web.UI.WebControls.WebParts.WebPart wp in webPartManager.WebParts)
                            {
                                string[] authFilter = wp.AuthorizationFilter.Split(';');
                                if (authFilter.GetLength(0) > 0 && !String.IsNullOrEmpty(authFilter[0]))
                                {
                                    Audience aud = audManager.GetAudience(new Guid(authFilter[0]));
                                    textStatus.AppendText(String.Format("+- Audience [{0}] Found in Web Part [{1}] is {2}\r\n", authFilter[0], wp.Title, (aud == null) ? "Invalid" : "Valid: [" + aud.AudienceName + "]"));
                                    string newFilter;

                                    if ((aud == null && findStatus == 1) ||
                                        (findStatus > 1 && textGUID.Text == authFilter[0]))
                                    {
                                        // Do the Removing thing
                                        if (replaceStatus == 3)
                                        {
                                            textStatus.AppendText(String.Format("  +-- Audience [{0}] has been removed.\r\n", authFilter[0]));
                                            found++;

                                            if(!test)
                                            {
                                                authFilter[0] = "";
                                                newFilter = String.Join(";", authFilter);
                                                wp.AuthorizationFilter = newFilter;
                                                webPartManager.SaveChanges(wp);
                                            }
                                        }
                                        
                                    }
                                    if (replaceStatus == 2 && textGUID.Text == authFilter[0])
                                    {
                                        textStatus.AppendText(String.Format("  +-- Audience {0} was replaced by Audience {1}.\r\n", authFilter[0], newAudience));
                                        found++;
                                        if (!test)
                                        {
                                            authFilter[0] = newAudience;
                                            newFilter = String.Join(";", authFilter);
                                            wp.AuthorizationFilter = newFilter;
                                            webPartManager.SaveChanges(wp);
                                        }


                                    }
                                    textStatus.Refresh();
                                    Application.DoEvents();
                                }
                                wp.Dispose();
                                textStatus.Refresh();
                                Application.DoEvents();

                            }

                        }
                        button5.Enabled = true;
                        if (found > 0)
                        {
                            textStatus.AppendText(String.Format("\r\nResults: {0} Webpart(s) matched your criteria in this site collection\r\n", found));
                        }
                        else
                        {
                            textStatus.AppendText("\r\nResults: No Webparts matched your criteria in this site collection\r\n");
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                textStatus.AppendText(String.Format("An error was found and the process stopped: {0}\r\n", ex.Message));
                MessageBox.Show(ex.Message, "Problem Enumerating Audiences");
                button5.Enabled = false;
            }

        }

        private void maskedTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!("0123456789abcdefABCDEF".Contains(e.KeyChar)))
            {
                e.KeyChar = '*';
            } else e.KeyChar = Char.ToLower(e.KeyChar);
           
        }

        private int findStatus = 1;
        private int replaceStatus = 1;
        private string siteURL = "http://" + Environment.MachineName.ToLower();

        private void ChangeFindStatus(object rb)
        {
            if ((rb as System.Windows.Forms.RadioButton).Checked)
                findStatus = Int32.Parse((rb as System.Windows.Forms.RadioButton).Tag.ToString());
        }

        private void ChangeReplaceStatus(object rb)
        {
            if ((rb as System.Windows.Forms.RadioButton).Checked)
                replaceStatus = Int32.Parse((rb as System.Windows.Forms.RadioButton).Tag.ToString());
        }


        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            ChangeFindStatus(sender);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            ChangeFindStatus(sender);
            bool enabled = (findStatus == 2);
            comboAudiences1.Enabled = enabled;
            buttonPopulate1.Enabled = enabled;

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            ChangeFindStatus(sender);
            bool enabled = (findStatus == 3);
            textGUID.Enabled = enabled;

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            ChangeReplaceStatus(sender);
            bool enabled = (findStatus == 2);
            comboAudiences2.Enabled = enabled;
            buttonPopulate2.Enabled = enabled;

        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            ChangeReplaceStatus(sender);
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            ChangeReplaceStatus(sender);
        }

        private void textURL_Leave(object sender, EventArgs e)
        {
            if (siteURL != textURL.Text)
            {
                button5.Enabled = false;
                buttonPopulate1.Enabled = false;
                buttonPopulate1.Enabled = false;

                radioButton5.Enabled = true;
                radioButton6.Enabled = true;

                siteURL = textURL.Text;
            }
        }

        private void buttonPopulate_Click(object sender, EventArgs e)
        {
            try
            {
                comboAudiences1.Items.Clear();
                comboAudiences2.Items.Clear();

                using (SPSite site = new SPSite(siteURL))
                {
                    ServerContext context = ServerContext.GetContext(site);
                    AudienceManager audManager = new AudienceManager(context);

                    foreach (Audience aud in audManager.Audiences)
                    {
                        comboAudiences1.Items.Add("["+aud.AudienceName+"]- Id: "+aud.AudienceID.ToString("D"));
                        comboAudiences2.Items.Add("[" + aud.AudienceName + "]- Id: " + aud.AudienceID.ToString("D"));
                    }


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Problem retrieving Audiences");
            }

        }

        private void comboAudiences1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string temp = comboAudiences1.SelectedItem.ToString();
            if(temp != null && temp.Length > 36)
            textGUID.Text = temp.Substring(temp.Length - 36);
        }

        private void Form1_ResizeEnd(object sender, EventArgs e)
        {
            //textStatus.Top = 356;
        }

        private void textStatus_LocationChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            License_AboutBox1 lBox = new License_AboutBox1();
            lBox.ShowDialog();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
                License_AboutBox1 license = new License_AboutBox1();
                if (!license.Checked)
                {
                    license.MainForm = this;
                    license.ShowDialog();
                }
        }
    }
}


