﻿//----------------------------------------------------------------------------------------------
//    Copyright 2012 Microsoft Corporation
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//      http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
//----------------------------------------------------------------------------------------------

// For this database test:
// Username: jdoe
// Password: password1

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Xml;
using System.Xml.Linq;

namespace WSFederationSecurityTokenService
{
    public class XmlFederationHandler: IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            HttpRequest Request = context.Request;
            HttpResponse Response = context.Response;

            if (Request.Path.ToLower().EndsWith("federationmetadata/2007-06/federationmetadata.xml"))
            {
                Response.ContentType = "text/xml";
                
                var stsConfiguration = new CustomSecurityTokenServiceConfiguration();
                var fedMet = stsConfiguration.GetFederationMetadataReader();
 
                Response.BinaryWrite(fedMet);
            }
            else
            {
                Response.Clear();
                Response.StatusCode = 404;
                Response.Status = "Not Found";
            }
        }

        public bool IsReusable
        {
            get { return true; }
        }
    }
}