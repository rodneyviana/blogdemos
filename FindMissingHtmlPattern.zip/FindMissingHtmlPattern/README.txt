This script and application enables you to identify list pages and views not containing new document or drag files here"

STEPS:
=================

ON THE SERVER:
- Run script "GeneratePagesList.ps1" to generate the list of candidate pages
- After you finish creating the list, copy it to a place you can find to do the steps on the client

Examples:

1. To dump all cadidate pages from a Web Site (Web Application) use this:

.\GeneratePagesList.ps1 -Url http://portal.contoso.com -AllSC -Recurse

Replace http://portal.contoso.com by your Web Site url


2. To dump a site and all webs under it:

.\GeneratePagesList.ps1 -Url http://portal.contoso.com -Recurse

3. To dump just the a web:
.\GeneratePagesList.ps1 -Url http://portal.contoso.com -UrlIsWeb

ON THE CLIENT (OR SERVER)
- Run FindMissingHtmlPattern.exe
- Select the input file created by the script on the previous step
- Click Process

IN CASE OF FAILURE:
- Running FindMissingHtmlPattern.exe and choosing the same input and output file will make the application continues from where it stopped

