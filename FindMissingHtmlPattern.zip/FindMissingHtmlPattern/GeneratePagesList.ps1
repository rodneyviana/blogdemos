﻿##########################################
#### Begin GeneratePagesList.ps1
##########################################

param(
    [Parameter(Mandatory=$true,Position=1,HelpMessage="Enter the path to site or web application to process -ex 'https://aplworksuat13.jhuapl.edu'")]
    [string]$Url,
    [Parameter(Mandatory=$false,Position=2,HelpMessage="Recurse subwebs -ex '-recurse'")]
    [switch]$Recurse = $false,
    [Parameter(Mandatory=$false,Position=3,HelpMessage="Examine all site collections-ex '-allsc'")]
    [switch]$AllSC,
    [Parameter(Mandatory=$false,Position=4,HelpMessage="Web Part Log File location -ex 'c:\temp\webpart_log.txt'")]
    [string]$WebPartlogFile = "$($env:TEMP)\WEBPART_LOG_$((Get-Date).ToString('yyyyMMddHHmmssfff')).txt",
    [Parameter(Mandatory=$false,Position=2,HelpMessage="Url is a specific web, only process it -ex '-UrlIsWeb'")]
    [switch]$UrlIsWeb = $false
    
)



Add-PSSnapin Microsoft.Sharepoint.Powershell
$Global:count = 0;
function main() {

    Write-Host "Log File: $WebPartlogFile"

    if($UrlIsWeb) {
        $spweb = Get-SPWeb $Url
        processWeb $spweb
        $spweb.Dispose()
    }

    elseif($AllSC) {
        $site = Get-SPSite $Url
        foreach($spsite in $site.WebApplication.Sites) {
            processSite $spsite
        }

        $site.Dispose()
    }
    else {
        processSiteUrl $Url

    }
    

    Write-Host "---------------------------------------------------";
    Write-Host "$($Global:count) Pages Listed";
    Write-Host "List of candidate pages saved to $WebPartlogFile"
    notepad $WebPartlogFile
}



function processWeb($spweb) {
    Write-Host "*** Processing web $($spweb.Url)"



    Write-Host "List of pages with Document.WebPart"
    Write-Host "---------------------------------------------------";
   foreach($list in $spweb.Lists)
    {  
       $UrlList = New-Object 'Collections.Generic.List[String]';
       foreach($view in $list.Views)
       {
          $wpmanager = $spweb.GetLimitedWebPartManager($view.Url, [System.Web.UI.WebControls.WebParts.PersonalizationScope]::Shared)

          foreach($webpart in $wpmanager.WebParts)
          {
            if($webpart.XmlDefinition -ne $null -and $webpart.XmlDefinition.Contains('BaseViewID="1"'))
            {
               foreach($schema in ($webpart.WebBrowsableObject.Schema.Values | Select Name))
               {
                 
                 if($schema.Name -eq 'LinkFilenameNoMenu')
                 {
                   $pageStr = $spweb.Url + "/" + $view.Url;
                   Write-Host $pageStr
                   [System.IO.File]::AppendAllLines($WebPartlogFile, ([System.String[]]@($pageStr)))
                   $Global:count++;
                 }
               }
            }
            $webpart.Dispose();
          }
          $wpmanager.Dispose();

       }

       if($list.BaseTemplate.ToString() -eq  'WebPageLibrary')
       {
         foreach($page in $list.Items)
         {

          $wpmanager = $spweb.GetLimitedWebPartManager($page.Url, [System.Web.UI.WebControls.WebParts.PersonalizationScope]::Shared)
          foreach($webpart in $wpmanager.WebParts)
          {
            if($webpart.XmlDefinition -ne $null -and $webpart.XmlDefinition.Contains('BaseViewID="1"'))
            {
               foreach($schema in ($webpart.WebBrowsableObject.Schema.Values | Select Name))
               {
                 
                 if($schema.Name -eq 'LinkFilenameNoMenu')
                 {
                   $pageStr = $spweb.Url + "/" + $page.Url;
                   Write-Host $pageStr
                   [System.IO.File]::AppendAllLines($WebPartlogFile, ([System.String[]]@($pageStr)))

                   $Global:count++;
                 }
               }
            }
            $webpart.Dispose();
          }
          $wpmanager.Dispose();
         }


       }
    }

}

function processSite($spsite) {
Write-Host "Processing Site Collection: $($spsite.Url)"

    $i=0;
    if($spsite -ne $null)
    {
      if($Recurse) {
        foreach($spweb in $spsite.AllWebs)
        {
            processWeb $spweb
            $spweb.Dispose();
        }
      }
      else {
        processWeb $spsite.RootWeb
      }
    }
}

function processSiteUrl($Url) {


    $spsite = Get-SPSite $Url

    if($spsite -eq $null) {
       Write-Host "Site could not be found at $Url"
       return
    } 

    processSite $spSite 

   

    $spsite.Dispose()
}


main

& notepad $WebPartlogFile

##########################################
#### End GeneratePagesList.ps1
##########################################


