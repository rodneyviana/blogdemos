﻿//
//  License: MIT
//  Author: Rodney Viana
//
/*
MIT License

Copyright(c) 2017 Microsoft

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace FindMissingHtmlPattern
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string[] listOfUrls = null;


        private void SetOutPutFileName()
        {
            if (String.IsNullOrWhiteSpace(textInput.Text))
            {
                textOutput.Text = String.Empty;
            }
            string outfullPath = Path.ChangeExtension(openFileDialog1.FileName, "") + "_output.TXT";
            textOutput.Text = outfullPath;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                textInput.Text = openFileDialog1.FileName;

                SetOutPutFileName();
                button2.Enabled = true;
                button3.Enabled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            saveFileDialog1.FileName = textOutput.Text;
            saveFileDialog1.InitialDirectory = Path.GetFullPath(textOutput.Text).Replace(Path.GetFileName(textOutput.Text), "");

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    listOfUrls = File.ReadAllLines(openFileDialog1.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString(), "Error");
                    return;
                }
            }

        }

        protected string initialUrl = null;
        protected bool found;
        protected int index = 0;
        AutoResetEvent waitHandle = null;
        private void button3_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;

            webBrowser1.ScriptErrorsSuppressed = !checkBox1.Checked;
            try
            {
                listOfUrls = File.ReadAllLines(textInput.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error");
                return;
            }
            progressBar1.Minimum = 0;
            progressBar1.Maximum = listOfUrls.Length - 1;

            found = true;
            initialUrl = null;
            if (File.Exists(textOutput.Text))
            {
                string[] lastUrls = File.ReadAllLines(textOutput.Text);
                int l = lastUrls.Length - 1;
                while (l >= 0)
                {
                    if (!String.IsNullOrWhiteSpace(lastUrls[l]))
                    {
                        initialUrl = lastUrls[l].Replace("(OK)", "").Replace("(Missing)", "");
                        found = false;
                        l = 0;
                    }
                    l--;
                }
            }
            int skip = 0;
            for (index = 0; index < listOfUrls.Length; index++)
            {
                progressBar1.Value = index;
                if (found)
                {
                    textUrl.Text = listOfUrls[index];
                    this.Refresh();

                    waitHandle = new AutoResetEvent(false);

                    //Thread td = new Thread(delegate ()
                    //{
                    webBrowser1.Navigate(listOfUrls[index]);
                    Application.DoEvents();
                    //    Thread.Sleep(10000);
                    //});

                    //td.Start();
                    while (!waitHandle.WaitOne(10))
                    {
                        Application.DoEvents();
                    }
                    if (waitHandle != null)
                        waitHandle.Dispose();
                    File.AppendAllLines(textOutput.Text,
                        new string[] { String.Format("({0}){1}", (bool)webBrowser1.Tag ? "OK" : "Missing", listOfUrls[index]) });
                }
                else
                {
                    skip++;
                    textUrl.Text = "(skipping) " + listOfUrls[index];
                }

                if (listOfUrls[index] == initialUrl)
                {
                    found = true;
                }
                this.Refresh();
            }
            MessageBox.Show(String.Format("Total: {0}{1}Skipped: {2}", listOfUrls.Length, Environment.NewLine, skip), "Finished");
            button1.Enabled = true;
            button3.Enabled = true;

        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            //if (webBrowser1.Document != null)
            //    webBrowser1.Document.Window.Error += new HtmlElementErrorEventHandler(Window_Error);

            if (waitHandle == null)
                return;

            webBrowser1.Tag = false;

            try
            {
                if(webBrowser1 == null || webBrowser1.Document == null)
                {
                    waitHandle.Set();
                    return;
                }
                var tables = webBrowser1.Document.GetElementsByTagName("table");


                if (tables == null || tables.Count < 1)
                {

                    waitHandle.Set();
                    return;
                }

                foreach (HtmlElement table in tables)
                {
                    if (table != null && !String.IsNullOrEmpty(table.InnerText) && table.InnerText.Contains("new document or drag files here"))
                    {
                        webBrowser1.Tag = true;
                        waitHandle.Set();
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                textUrl.Text = ex.ToString();
                textUrl.Refresh();
                Thread.Sleep(3000); // 3 seconds to see the error
            }
            waitHandle.Set();

        }

        private void webBrowser1_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {

        }

        private void Window_Error(object sender, HtmlElementErrorEventArgs e)
        {
            e.Handled = true;
        }

        private void webBrowser1_LocationChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
