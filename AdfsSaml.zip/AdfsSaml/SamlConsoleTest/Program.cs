﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Samples.AdfsSaml;

//The code samples are provided AS IS without warranty of any kind. 
// Microsoft disclaims all implied warranties including, without limitation, 
// any implied warranties of merchantability or of fitness for a particular purpose. 

/*
 
The entire risk arising out of the use or performance of the sample scripts and documentation remains with you. 
In no event shall Microsoft, its authors, or anyone else involved in the creation, production, or delivery of the scripts 
be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use of or inability to use the sample scripts 
or documentation, even if Microsoft has been advised of the possibility of such damages.
 
*/

namespace SamlConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Test SAML Response Test Library");
            Console.WriteLine("===============================");
            Console.Write("\n\nLicense is GPLv2 (http://rodneyviana.codeplex.com/license)\nClick Ctrl+C if you do not agree or any other key to continue...");
            Console.ReadKey();

            string url;
            if (args.Length == 1)
            {
                url = args[0];
            }
            else
            {
                Console.Write("\n\nEnter Url of ADFS Server: ");
                url = Console.ReadLine();

            }
            Console.WriteLine("\n");
            SamlResponse samlResponse = new SamlResponse(new Uri(url));
            string[] rps = samlResponse.GetReliantPartyCollection();
            Console.WriteLine("List of reliant parties");
            Console.WriteLine("=======================");
            for(int i=0;i<rps.Length;i++)
            {
                Console.WriteLine("{0}. {1}", i+1, rps[i]);
            }
            if (rps.Length == 0)
            {
                Console.WriteLine("No reliant party found. Exiting");
                return;
            }
            Console.Write("\nChose a number between 1 and {0}: ", rps.Length);
            string sel = Console.ReadLine();
            uint choice = UInt32.Parse(sel);
            if(choice == 0 || choice > rps.Length)
            {
                Console.WriteLine("Invalid choice. Exiting.");
                return;
            }
            string samlString = samlResponse.RequestSamlResponse(rps[choice - 1]);
            Console.WriteLine("Raw response: {0}", samlString);
            Console.WriteLine("\n\nFormatted Response:");
            Console.WriteLine("===================");
            Console.WriteLine(SamlResponse.SamlToXmlString(samlString));
            Console.Write("\n\nPress any key to exit...");
            Console.ReadKey();

        }
    }
}
