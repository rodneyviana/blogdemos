﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Web;
using System.Xml;
using System.IO;

//The code samples are provided AS IS without warranty of any kind. 
// Microsoft disclaims all implied warranties including, without limitation, 
// any implied warranties of merchantability or of fitness for a particular purpose. 

/*
 
The entire risk arising out of the use or performance of the sample scripts and documentation remains with you. 
In no event shall Microsoft, its authors, or anyone else involved in the creation, production, or delivery of the scripts 
be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use of or inability to use the sample scripts 
or documentation, even if Microsoft has been advised of the possibility of such damages.
 
*/

namespace Microsoft.Samples.AdfsSaml
{
    /// <summary>
    /// Class to get a SAML response from ADFS.
    /// it requires that the SAML endpoint with POST binding is configured in ADFS
    /// </summary>
    public class SamlResponse
    {

        /// <summary>
        /// If true, ADFS url will not be validated
        /// </summary>
        public bool EnableRawUrl
        {
            get;
            set;
        }

        private Uri serverAddress = null;
        private HttpClient client = null;
        private HttpClientHandler handler;

        private HttpClient Client
        {
            get
            {
                if (client == null)
                {
                    handler = new HttpClientHandler();
                    handler.UseDefaultCredentials = true;
                    handler.AllowAutoRedirect = false;
                    handler.CookieContainer = new System.Net.CookieContainer();
                    handler.UseCookies = true;
                    client = new HttpClient(handler);
                    client.MaxResponseContentBufferSize = 256000;
                    client.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)");
                    client.DefaultRequestHeaders.Add("Connection", "Keep-Alive");
                    client.DefaultRequestHeaders.ExpectContinue = false;
                }
                return client;
            }
        }

        /// <summary>
        /// Url of ADFS server (e.g. https://adfs.contoso.com)
        /// </summary>
        public Uri ServerAddress
        {
            get
            {
                return serverAddress;
            }
            set
            {
                if(EnableRawUrl)
                {
                    serverAddress = value;
                    return;
                }
                string host = value.Host;
                string scheme = value.Scheme;
                if(scheme != "https")
                {
                    throw new ArgumentException("ADFS rquires scheme https. Set EnableRawUrl to true to override it", "ServerAddress");
                }
                serverAddress = new Uri(String.Format("https://{0}//adfs/ls/IdpInitiatedSignOn.aspx", host));
            }
        }
        /// <summary>
        /// Initialize the class
        /// </summary>
        public SamlResponse()
        {

        }

        /// <summary>
        /// Initialize the class
        /// </summary>
        /// <param name="Url">Urn of reliant party as defined in ADFS. Ise GetReliantPArtyCollection to get the list</param>
        /// <param name="IsRawUrl">If true, ADFS url will not be validated</param>
        public SamlResponse(Uri Url, bool IsRawUrl = false)
        {
            EnableRawUrl = IsRawUrl;
            ServerAddress = Url;
        }

        private async Task<string[]> GetReliantPartyCollectionInternal()
        {
            if (serverAddress == null)
            {
                throw new NullReferenceException("ServerAddress was not set");
            }

            var response = await Client.GetAsync(serverAddress);
            response.EnsureSuccessStatusCode();
            string text = await response.Content.ReadAsStringAsync();
            Regex reg = new Regex("option\\W+value\\=\\\"([^\\\"]+)\\\"");
            MatchCollection matches = reg.Matches(text);
            if(matches.Count == 0)
            {
                return null;
            }
            string[] rps = new string[matches.Count];
            uint i = 0;
            foreach (Match m in matches)
            {
                rps[i++]=m.Groups[1].Value;
            }
            return rps;
        }


        /// <summary>
        /// Get the list of Reliant Parties with SAML endpoint with binding POST in ADFS
        /// </summary>
        public string[] GetReliantPartyCollection()
        {
            return GetReliantPartyCollectionInternal().Result;
        }

        /// <summary>
        /// Retrieve the SAML Response from ADFS for ReliantPartyUrn
        /// </summary>
        /// <param name="ReliantPartyUrn">Urn of reliant party as defined in ADFS. Ise GetReliantPArtyCollection to get the list</param>
        public string RequestSamlResponse(string ReliantPartyUrn)
        {
            if(serverAddress == null)
            {
                throw new NullReferenceException("ServerAddress was not set");
            }
            if(String.IsNullOrEmpty(ReliantPartyUrn) && !EnableRawUrl)
            {
                throw new ArgumentException("Reliant Party Urn cannot be empty if EnableRawUrl is not true");
            }


            return SamlResponseInternal(ReliantPartyUrn).Result;
            
        }

        private async Task<string> SamlResponseInternal(string ReliantPartyUrn)
        {

            StringBuilder url = new StringBuilder(String.Format("{0}?loginToRp={1}", serverAddress, HttpUtility.UrlEncode(ReliantPartyUrn)));
            HttpResponseMessage result;
            
            do
            {
                result = await Client.GetAsync(url.ToString());

                string text = await result.Content.ReadAsStringAsync();
                IEnumerable<string> values;
                if (result.Headers.TryGetValues("location", out values))
                {
                    foreach (string s in values)
                    {
                        if (s.StartsWith("/"))
                        {
                            string newUrl = url.ToString().Substring(0, url.ToString().IndexOf("/adfs/ls"));
                            url.Clear();
                            url.Append(newUrl);
                            url.Append(s);
                        }
                        else
                        {
                            url.Clear();
                            url.Append(s);
                        }
                    }

                }
                else
                {
                    url.Clear();
                }
                if (url.Length == 0)
                {
                    Regex reg = new Regex("SAMLResponse\\W+value\\=\\\"([^\\\"]+)\\\"");
                    MatchCollection matches = reg.Matches(text);
                    foreach (Match m in matches)
                    {
                        return m.Groups[1].Value;
                    }
                }

            } while (url.Length > 0);
            throw new InvalidOperationException("Unable to get a SAMLP response from ADFS");
        }

        public static string SamlToXmlString(string EncodedResponse)
        {
            byte[] decoded = Convert.FromBase64String(EncodedResponse);

            string deflated = Encoding.UTF8.GetString(decoded);
            XmlDocument doc = new XmlDocument();
            StringBuilder sb = new StringBuilder();
            doc.LoadXml(deflated);

            using (StringWriter sw = new StringWriter(sb))
            {
                using (XmlTextWriter tw = new XmlTextWriter(sw) { Formatting = Formatting.Indented })
                {
                    doc.WriteTo(tw);
                }
            }
            return sb.ToString();

        }
    }
}
