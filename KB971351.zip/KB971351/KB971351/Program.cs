﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using System.Xml;

namespace KB971351
{
    class Program
    {
        static private string RenderXMLPattenAttribute = "RenderXMLUsingPattern";
        static private string webUrl = "http://localhost";

        static void FixList()
        {
            Console.Write("Please enter web site (http://localhost): ");
            string inputWeb = Console.ReadLine();
            if (!String.IsNullOrEmpty(inputWeb))
                webUrl = inputWeb;
            Console.WriteLine("\nTrying to open web site: {0}", webUrl);
            string listName = null;
            try
            {
                using (SPSite site = new SPSite(webUrl))
                {
                    Console.WriteLine("Web site {0} found", webUrl);
                    using (SPWeb web = site.OpenWeb())
                    {
                        while (String.IsNullOrEmpty(listName))
                        {
                            Console.Write("Enter list name or press [enter] to display all lists: ");
                            listName = Console.ReadLine();
                            if (String.IsNullOrEmpty(listName))
                            {
                                for (int i = 0; i < web.Lists.Count; i++)
                                {
                                    if (!web.Lists[i].Hidden)
                                        Console.WriteLine(web.Lists[i].Title);
                                }
                            }

                        }

                        SPList list = web.Lists[listName];
                        SPField f = list.Fields.GetFieldByInternalName("PermMask");
                        string s = f.SchemaXml;
                        XmlDocument xd = new XmlDocument();
                        xd.LoadXml(s);
                        XmlElement xe = xd.DocumentElement;
                        if (xe.Attributes[RenderXMLPattenAttribute] == null)
                        {
                            XmlAttribute attr = xd.CreateAttribute(RenderXMLPattenAttribute);
                            attr.Value = "TRUE";
                            xe.Attributes.Append(attr);
                            string strXml = xe.OuterXml;
                            f.SchemaXml = strXml;
                            Console.WriteLine("SUCESS: problem identified in KB 971351 was found and fixed");
                        }
                        else
                        {
                            Console.WriteLine("WARNING: problem identified in KB 971351 was NOT found. No change was made");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("\nApplication Failed with error: {0}", ex.Message);
                Console.WriteLine("No changes were made. Please run application again");

            }

        }

        static void FixWeb()
        {
            Console.Write("Please enter web site (http://localhost): ");
            string inputWeb = Console.ReadLine();
            if (!String.IsNullOrEmpty(inputWeb))
                webUrl = inputWeb;
            Console.WriteLine("\nTrying to open web site: {0}", webUrl);
            try
            {
                using (SPSite site = new SPSite(webUrl))
                {
                    Console.WriteLine("Web site {0} found", webUrl);
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPField f = web.Fields.GetFieldByInternalName("PermMask");
                        string s = f.SchemaXml;
                        XmlDocument xd = new XmlDocument();
                        xd.LoadXml(s);
                        XmlElement xe = xd.DocumentElement;
                        if (xe.Attributes[RenderXMLPattenAttribute] == null)
                        {
                            XmlAttribute attr = xd.CreateAttribute(RenderXMLPattenAttribute);
                            attr.Value = "TRUE";
                            xe.Attributes.Append(attr);
                            string strXml = xe.OuterXml;
                            f.SchemaXml = strXml;
                            Console.WriteLine("SUCESS: problem identified in KB 971351 was found and fixed");
                        }
                        else
                        {
                            Console.WriteLine("WARNING: problem identified in KB 971351 was NOT found. No change was made");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("\nApplication Failed with error: {0}", ex.Message);
                Console.WriteLine("No changes were made. Please run application again");

            }

        }


        static void Main(string[] args)
        {
            Console.WriteLine("Implementation of code in KB 971351");
            Console.WriteLine("====================================");
            Console.WriteLine("Written by Rodney Viana");
            Console.WriteLine("More info at http://blogs.msdn.com/rodneyviana and http://support.microsoft.com/kb/971351 \n");
            Console.WriteLine("This sample application is supplied \"AS IS\"");
            Console.WriteLine("It is ONLY for demonstration/proof of concept purposes");
            Console.WriteLine("If you DO NOT agree with the license at:\n\thttp://www.codeplex.com/rodneyviana/license\n\tPress Ctrl+C\n\n\n");
            Console.WriteLine("Choose one of the options below:");
            Console.WriteLine("0. If you don't want to do it now and end the application");
            Console.WriteLine("1. If you are experiencing problems in anye web site fields");
            Console.WriteLine("2. If you are experiencing problems in a list or document library");
            ConsoleKeyInfo key = new ConsoleKeyInfo();
            while(key == null || (key.KeyChar != '0' && key.KeyChar != '1' && key.KeyChar != '2'))
            {
                key = Console.ReadKey();
            }

            if(key.KeyChar == '1')
            {
                Console.WriteLine("You have chosen to fix a web site");
                FixWeb();
            }

            if(key.KeyChar == '2')
            {
                Console.WriteLine("You have chosen to fix a list");
                FixList();
            }

            if(key.KeyChar == '0')
            {
                Console.WriteLine("You have chosen to abort application");
            }
            Console.Write("Press any key...");
            Console.ReadKey();

        }
    }
}
