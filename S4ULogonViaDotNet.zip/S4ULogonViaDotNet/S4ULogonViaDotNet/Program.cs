﻿using System;
using System.Text;
using System.Security.Principal;
using System.IO;
using System.Net;
using System.Diagnostics;

// This sample code is provided “AS IS” with no guarantees and its meant for proof-of-concept ONLY.  
// You need to accept this license to use it: http://rodneyviana.codeplex.com/license 


//The code samples are provided AS IS without warranty of any kind. 
// Microsoft disclaims all implied warranties including, without limitation, 
// any implied warranties of merchantability or of fitness for a particular purpose.
// The entire risk arising out of the use or performance of the sample scripts and documentation remains with you.
// In no event shall Microsoft, its authors, or anyone else involved in the creation, production,
// or delivery of the scripts be liable for any damages whatsoever (including, without limitation, damages for
// loss of business profits, business interruption, loss of business information, or other pecuniary loss) arising 
// out of the use of or inability to use the sample scripts or documentation, even if Microsoft has been advised 
// of the possibility of such damages. 

namespace S4ULogonViaDotNet
{
    class Program
    {

        static protected ConsoleColor back = Console.BackgroundColor;
        static protected ConsoleColor fore = Console.ForegroundColor;

        static protected void Bold()
        {
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.White;
        }

        static protected void DisplayLink(string Url)
        {

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.Write(Url);
            Normal();

        }
        static protected void Normal()
        {
            Console.BackgroundColor = back;
            Console.ForegroundColor = fore;
        }



        static void Main(string[] args)
        {

            Console.WriteLine("S4ULogonViaDotNet");
            Console.WriteLine("=================\n");

            Console.WriteLine("Test UPN login using the same Windows API that c2WTS (Claims to ");
            Console.WriteLine("Windows NT Token Service) uses. If the test fails here, the problem");
            Console.WriteLine("is in your Active Directory configuration or your Kerberos settings.");
            Console.WriteLine("");
            Console.Write("License: GPLv2 (see full license here: ");
            DisplayLink("http://rodneyviana.codeplex.com/license");
            Console.WriteLine(")");
            Console.WriteLine("");
            Bold();
            Console.WriteLine("The process is running under credential: {0}\n * Make sure it matches c2WTS service account.", GetPrincipal());
            Normal();

            Console.WriteLine("");
            Console.WriteLine("IMPORTANT: To run this application as SYSTEM account (default for c2WTS): ");
            Console.Write(" 1. Download SysInternals psexec (or psexec64) at\n ");

            DisplayLink("http://technet.microsoft.com/en-us/sysinternals/bb897553.aspx");
            Console.WriteLine("");
            Console.Write(" 2. Run from an elevated command prompt:\n ");
            Bold();
            Console.WriteLine("psexec \\\\localhost -s -i {0}\n", Environment.CommandLine);
            Normal();


            string upn = null;
            string target = null;
            if (args.Length == 0)
            {
                Console.Write("Enter upn (e.g. john@contoso.com): ");
                upn = Console.ReadLine();
                Console.Write(@"Enter target (e.g. http://server1 or \\server1\share1\file1.txt): ");
                target = Console.ReadLine();

            }
            else
            {
                upn = args[0];
                if(args.Length > 1)
                    target = args[1];
            }

            if (String.IsNullOrEmpty(upn) || upn.Contains("?"))
            {
                Console.WriteLine("\nUsage: S4ULogonViaDotNet [UPN] [file]");
                Console.WriteLine("\nExample: S4ULogonViaDotNet john@contoso.com http://server1");

                return;

            }


            try
            {
                WindowsIdentity s4u = new WindowsIdentity(upn);

                WindowsImpersonationContext wic = s4u.Impersonate();
                Console.WriteLine("");
                Bold();
                Console.WriteLine("Identity {0} acquired successfuly", WindowsIdentity.GetCurrent().Name);

                Normal();

                if (target.StartsWith("\\"))
                {
                    using (StreamReader infile = new StreamReader(target))
                    {
                        //
                        // It will throw exception if it can't read
                        //
                        infile.ReadLine();
                        infile.Close();
                    }
                } else
                    if (target.ToLower().StartsWith("http"))
                    {
                        /*
                         * If you want to test access to a WCF service instead of a
                         *   regular web page, change the code below to create a
                         *   WCF proxy and call a method to test
                         */
                        WebClient wc = new WebClient();
                        string reply = wc.DownloadString(target);
                    }
                    else
                    {
                        if(!String.IsNullOrEmpty(target))
                            throw new Exception("Warning: Resource not recognized or empty. It has to start with \\\\ for a share or with http for a web resource");
                    }
                if (!String.IsNullOrEmpty(target)) 
                    Console.WriteLine("Reading target {0} was succesfull.", target);

            }
            catch (Exception ex)
            {
                Console.WriteLine("{0}: {1}\n{2}", ex.GetType().ToString(), ex.Message, ex.StackTrace);
            }
            Console.Write("Press any key to continue...");
            Console.ReadKey();
        }

        protected static string GetPrincipal()
        {
            return System.Security.Principal.WindowsIdentity.GetCurrent().Name;
        }

    }
}
