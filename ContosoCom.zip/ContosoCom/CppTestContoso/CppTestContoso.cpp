// CppTestContoso.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#import "C:\projects\ContosoCom\ContosoCom\bin\Debug\ContosoCom.tlb" auto_rename


using namespace ContosoCom;
typedef void(*pGetClass)(IMyClass **iMyClass);


int _tmain(int argc, _TCHAR* argv[])
{
	pGetClass getClass = NULL;
	IMyClass *mc = NULL;

	HINSTANCE hDLL = 0;
	// load the DLL

	hDLL = ::LoadLibrary(L"ContosoCom.dll");

	::CoInitialize(NULL);

	if(!hDLL)
	{
		printf("ERROR: Unable to load library ContosoCom.dll\n");
		return -1;
	}


	//
	// TO DO: Add code here to get an instance of MyClass
	//
	getClass = (pGetClass)GetProcAddress(hDLL, "GetClass");

	if(!getClass)
	{
		printf("ERROR: Unable to find entry for GetClass()\n");
		return -1;

	}

	getClass(&mc);

	// At this point we do not have how to get a pointer even with the libray loaded

	// End of TO DO

	if(!mc)
	{
		printf("ERROR: Unable to get a pointer for MyClass\n");
		return -1;
	}

	mc->DisplayMessageBox("Hello World from native to .NET without registration");
	MyStruct st;
	ZeroMemory(&st, sizeof(MyStruct));
	mc->GetTicksAndDate(&st);
	printf("Ticks %I64i\n",st.TicksOfNow);
	printf("Today is %i/%i/%i\n",st.Month,st.Day,st.Year);


	printf("SUCCESS: Leaving gracefully\n");
	return 0;
}

