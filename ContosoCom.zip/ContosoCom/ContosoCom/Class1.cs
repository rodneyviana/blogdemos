﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using RGiesecke.DllExport;


namespace ContosoCom
{

    public static class Exports
    {
        [DllExport(CallingConvention = CallingConvention.Cdecl)]
        public static void GetClass([Out] [MarshalAs((UnmanagedType.Interface))] out IMyClass pInterface)
        {
            pInterface = new MyClass();
        }
    }


    [ComVisible(true)]
    [System.Runtime.InteropServices.InterfaceTypeAttribute(System.Runtime.InteropServices.ComInterfaceType.InterfaceIsIUnknown)]
    public interface IMyClass
    {
        void DisplayMessageBox([MarshalAs(UnmanagedType.BStr)] string Text);
        void GetTicksAndDate([Out] out MyStruct Structure);
    }

    [ComVisible(true)]
    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    public struct MyStruct
    {
        public long TicksOfNow;
        public int Day;
        public int Month;
        public int Year;
    }

    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.None)]
    [ComDefaultInterface(typeof(IMyClass))]
    public class MyClass : IMyClass
    {

        public void DisplayMessageBox(string Text)
        {
            MessageBox.Show(Text);
        }

        public void GetTicksAndDate(out MyStruct Structure)
        {
            Structure.TicksOfNow = DateTime.Now.Ticks;
            Structure.Day = DateTime.Now.Day;
            Structure.Month = DateTime.Now.Month;
            Structure.Year = DateTime.Now.Year;
        }
    }
}
