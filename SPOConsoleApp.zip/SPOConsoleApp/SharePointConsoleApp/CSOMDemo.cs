﻿using System;
#region CSOM
using Microsoft.SharePoint.Client;
using PnP.Framework;
using System.Configuration;
#endregion

namespace SharePointConsoleApp
{
    public class CSOMDemo: IDisposable
    {
        private ClientContext context = null;
        private bool disposedValue;

        protected ClientContext Context { 
            get { 
                    if(context == null)
                    {
                        using (var manager = new AuthenticationManager())
                        {
                            context = manager.GetACSAppOnlyContext(UriContext, clientId, clientSecret);
                        }
                    }
                    return context;
                } 
            private set => context = value; }

        public string UriContext { get; protected set; } = null;
        protected string clientId;
        protected string clientSecret;

        public CSOMDemo(string Url)
        {
            UriContext = Url;
            clientId = ConfigurationManager.AppSettings["ClientId"];
            clientSecret = ConfigurationManager.AppSettings["ClientSecret"];
        }

        public CSOMDemo(string Url, string ClientId, string ClientSecret)
        {
            UriContext = Url;
            clientId = ClientId;
            clientSecret = ClientSecret;
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    if(context != null)
                    {
                        context.Dispose();
                    }
                }

                disposedValue = true;
            }
        }

        // // TODO: override finalizer only if 'Dispose(bool disposing)' has code to free unmanaged resources
        // ~CSOMDemo()
        // {
        //     // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
        //     Dispose(disposing: false);
        // }

        public void Dispose()
        {
            // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        public string GetWebTitle()
        {
            var web = Context.Web;
            Context.Load(web, w => w.Title);
            Context.ExecuteQuery();
            return web.Title;
        }

        public string GetToken()
        {
            return Context.GetAccessToken();
        }
    }
}
