﻿using Microsoft.SharePoint.Client;
using PnP.Framework;
using System;
using System.Configuration;
using System.Dynamic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace SharePointConsoleApp
{
    public class RESTAPIDemo : IDisposable
    {
        #region fields
        private bool disposedValue;
        private ClientContext context = null;
        private string uriContext;
        private string clientId;
        private string clientSecret;
        #endregion

        #region static
        private static HttpClient client = new HttpClient();
        #endregion
        protected ClientContext Context
        {
            get
            {
                if (context == null)
                {
                    using (var manager = new AuthenticationManager())
                    {
                        context = manager.GetACSAppOnlyContext(uriContext, clientId, clientSecret);
                    }
                }
                return context;
            }
            private set => context = value;
        }

        public dynamic GetList(string ListNameOrGUID, bool IsGuid = false, int Top = 1000, string Fields = null)
        {
            StringBuilder finalUrl = GetListPath(ListNameOrGUID, IsGuid, Top);
            finalUrl.Append($"?$top={Top}&");
            if (Fields != null)
            {
                finalUrl.Append($"$select={Uri.EscapeDataString(Fields)}");
            }
            var response = GetWebRequest(finalUrl.ToString()).GetAwaiter().GetResult();
            var body = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
            var obj = System.Text.Json.JsonSerializer.Deserialize<ExpandoObject>(body);
            return obj;
        }

        public dynamic GetListItems(string ListNameOrGUID, bool IsGuid = false, int Top = 1000, string Fields = null, string Filter = null)
        {
            StringBuilder finalUrl = GetListPath(ListNameOrGUID, IsGuid, Top);
            finalUrl.Append($"/items?$top={Top}&");
            if (Fields != null)
            {
                finalUrl.Append($"$select={Uri.EscapeDataString(Fields)}&");
            }
            if (Filter != null)
            {
                finalUrl.Append($"$filter={Uri.EscapeDataString(Filter)}");
            }
            var response = GetWebRequest(finalUrl.ToString()).GetAwaiter().GetResult();
            var body = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
            var obj = System.Text.Json.JsonSerializer.Deserialize<ExpandoObject>(body);
            return obj;
        }

        private static StringBuilder GetListPath(string ListNameOrGUID, bool IsGuid, int Top)
        {
            StringBuilder finalUrl = new StringBuilder();
            if (IsGuid)
            {
                finalUrl.Append((new Uri(client.BaseAddress, $"_api/web/lists(guid'{ListNameOrGUID}')")).AbsoluteUri);
            }
            else
            {
                finalUrl.Append((new Uri(client.BaseAddress, $"_api/web/lists/getbytitle('{Uri.EscapeDataString(ListNameOrGUID)}')")).AbsoluteUri);
            }
            return finalUrl;
        }

        public RESTAPIDemo(string Url)
        {
            uriContext = Url;
            clientId = ConfigurationManager.AppSettings["ClientId"];
            clientSecret = ConfigurationManager.AppSettings["ClientSecret"];
            using(var siteContext = Context.GetSiteCollectionContext())
                client.BaseAddress = new Uri(siteContext.Url);
        }

        public RESTAPIDemo(string Url, string ClientId, string ClientSecret)
        {
            uriContext = Url;
            clientId = ClientId;
            clientSecret = ClientSecret;
            using (var siteContext = Context.GetSiteCollectionContext())
                client.BaseAddress = new Uri(siteContext.Url);
        }

        public async Task<HttpResponseMessage> GetWebRequest(string Uri, string Token, string Digest)
        {
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer",Token);
            client.DefaultRequestHeaders.Remove("X-RequestDigest");
            client.DefaultRequestHeaders.Add("X-RequestDigest", Digest);

            HttpResponseMessage response = await client.GetAsync(Uri);
            return response;
        }

        public Task<HttpResponseMessage> GetWebRequest(string Uri)
        {
            return GetWebRequest(Uri, GetToken(), GetDigest());
        }


        public string GetToken()
        {
            return Context.GetAccessToken();
        }

        public string GetDigest()
        {
            var digest = Context.GetFormDigestDirect();
            return digest.DigestValue;
        }
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    context.Dispose();
                }

                // TODO: free unmanaged resources (unmanaged objects) and override finalizer
                // TODO: set large fields to null
                disposedValue = true;
            }
        }

        // // TODO: override finalizer only if 'Dispose(bool disposing)' has code to free unmanaged resources
        // ~RESTAPIDemo()
        // {
        //     // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
        //     Dispose(disposing: false);
        // }

        public void Dispose()
        {
            // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
}
