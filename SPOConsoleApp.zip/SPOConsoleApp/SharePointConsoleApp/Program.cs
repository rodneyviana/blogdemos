﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Text.Json;

namespace SharePointConsoleApp
{
    class Program
    {
        const string key = "<<KEY>>";      // replace by your key
        const string secret = "<<SECRET>>";   // replace by your secret

        static void Main(string[] args)
        {

            CSOMDemo csom = new CSOMDemo("https://contoso.sharepoint.com/", key, secret);  // replace by your site collection Uri
            var title = csom.GetWebTitle();
            var token = csom.GetToken();

            RESTAPIDemo rest = new RESTAPIDemo("https://contoso.sharepoint.com/", key, secret);  // replace by your site collection Uri
            var resp = rest.GetList("Documents", false, 1000, "Id,LastItemUserModifiedDate");
            ShowObject(resp, "List with Selected Fields");
            var resp1 = rest.GetList("Documents");
            ShowObject(resp1, "List with All fields");
            var resp2 = rest.GetList("27c9bb00-45c7-4e75-953f-621d46928133", true);  // replace by a valid list guid
            ShowObject(resp2, "List with All but by GUID");
            var resp3 = rest.GetListItems("Documents");
            ShowObject(resp3, "Items with All Fields");
            var resp4 = rest.GetListItems("Documents", false, 100, "Id,ID,Modified,Title", "ID eq 4");
            ShowObject(resp4, "Items with Selected Fields and Filter");
        }

        public static void ShowObject(dynamic Object, string Title = "Some Object", int Identation=0)
        {
            Console.WriteLine();
            string identStr = Identation == 0 ? "" : new string(' ', Identation);
            Console.WriteLine(identStr + Title);

            Console.WriteLine(identStr + new string('=', Title.Length));
            foreach (var property in (IDictionary<string, Object>)Object)
            {
                if (property.Value != null && ((System.Text.Json.JsonElement)(property.Value)).ValueKind == System.Text.Json.JsonValueKind.Array)
                {
                    var items = ((JsonElement)(property.Value)).EnumerateArray();
                    int i = 0;
                    while(items.MoveNext())
                    {
                        dynamic obj = JsonSerializer.Deserialize<ExpandoObject>(items.Current.GetRawText());
                        ShowObject(obj, $"--> {property.Key}[{i++}]", 8);
                    }
                    //var obj = JsonSerializer.Deserialize<ExpandoObject>(property.Value.ToString());
                    //ShowObject(obj, "--> Array Item");
                }
                else
                {
                    Console.WriteLine(identStr + property.Key + ": " + property.Value);
                }
            }
        }
    }


}
