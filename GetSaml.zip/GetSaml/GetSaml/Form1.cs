﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Text.RegularExpressions;
using System.Web;
using System.IO;
using System.IO.Compression;

//The code samples are provided AS IS without warranty of any kind. 
// Microsoft disclaims all implied warranties including, without limitation, 
// any implied warranties of merchantability or of fitness for a particular purpose. 

/*
 
The entire risk arising out of the use or performance of the sample scripts and documentation remains with you. 
In no event shall Microsoft, its authors, or anyone else involved in the creation, production, or delivery of the scripts 
be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use of or inability to use the sample scripts 
or documentation, even if Microsoft has been advised of the possibility of such damages.
 
*/

namespace GetSaml
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string getUrl = null;
        private string GetUrl
        {
            get
            {
                if (!String.IsNullOrEmpty(getUrl))
                    return getUrl;
                StringBuilder domain = new StringBuilder();
                domain.Append(Environment.GetEnvironmentVariable("USERDNSDOMAIN"));
                if (domain.Length > 0)
                {
                    domain.Clear();
                    domain.Append(Environment.UserDomainName);
                }
                
                //return String.Format("https://{0}.{1}.lab/adfs/ls/MyIdpInitiatedSignOn.aspx?loginToRp=https://mysyte.com", Environment.MachineName.ToLower(), Environment.UserDomainName.ToLower());
                return String.Format("https://{0}.{1}.lab/adfs/ls/IdpInitiatedSignOn.aspx", Environment.MachineName.ToLower(), Environment.UserDomainName.ToLower());
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = GetUrl;
        }

        protected List<KeyValuePair<string, string>> forms;

        private HttpClient client = null;
        private HttpClientHandler handler;

        private HttpClient Client
        {
            get
            {
                if (client == null)
                {
                    handler = new HttpClientHandler();
                    handler.UseDefaultCredentials = true;
                    handler.AllowAutoRedirect = false;
                    handler.CookieContainer = new System.Net.CookieContainer();
                    handler.UseCookies = true;
                    client = new HttpClient(handler);
                    client.MaxResponseContentBufferSize = 256000;
                    client.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)");
                    client.DefaultRequestHeaders.Add("Connection", "Keep-Alive");
                    client.DefaultRequestHeaders.ExpectContinue = false;


                }
                return client;
            }
        }

        private async void button1_Click(object sender, EventArgs e)
        {

            //handler.UseCookies = true;
            //handler.MaxAutomaticRedirections = 1;
            

            string url = String.Format("{0}?loginToRp={1}", textBox1.Text, HttpUtility.UrlEncode(comboBox1.SelectedItem.ToString()));
            // Limit the max buffer size for the response so we don't get overwhelmed
            HttpResponseMessage result;
            textBox3.Text="============== Start ===============";
            var nl = Environment.NewLine;

       

            string text;
            do
            {


                textBox3.AppendText(String.Format("{1}********** GET {0}{1}", url, Environment.NewLine));
                result = await Client.GetAsync(url);


                text = await result.Content.ReadAsStringAsync();
                IEnumerable<string> values;
                if(result.Headers.TryGetValues("location", out values))
                {
                    foreach(string s in values)
                    {

                        if (s.StartsWith("/"))
                        {
                            url = url.Substring(0, url.IndexOf("/adfs/ls")) + s;
                        }
                        else
                            url = s;
                    }

                } else
                {
                    url = "";
                }
                textBox3.AppendText(String.Format("{0}[Headers]{0}", Environment.NewLine));
                foreach(var pair in result.Headers)
                {
                    string key = pair.Key;
                    foreach(var val in pair.Value)
                        textBox3.AppendText(String.Format(" {0}={1}{2}", key, val, Environment.NewLine));
                }
                //var split = text.Split('\"');
                ////http
                //for (int i = 0; i < split.Length; i++)
                //{
                //    if (split[i].StartsWith("https") || split[i].StartsWith("%2f"))
                //    {
                //        url =   split[i];
                //        break;
                //    }

                //}

                textBox3.AppendText(text);
            } while (!String.IsNullOrEmpty(url));


            Regex reg = new Regex("SAMLResponse\\W+value\\=\\\"([^\\\"]+)\\\"");
            MatchCollection matches = reg.Matches(text);
            string last = null;
            foreach (Match m in matches)
            {
                last = m.Groups[1].Value;
                textBox3.AppendText(String.Format(" {1}{1}{1}SAMLResponse={0}{1}", last, Environment.NewLine));
            }
            if(last != null)
            {

                byte[] decoded = Convert.FromBase64String(last);

                string deflated = Encoding.UTF8.GetString(decoded);
                XmlDocument doc = new XmlDocument();
                StringBuilder sb = new StringBuilder();
                doc.LoadXml(deflated);

                using(StringWriter sw = new StringWriter(sb))
                {
                    using (XmlTextWriter tw = new XmlTextWriter(sw) { Formatting = Formatting.Indented })
                    {
                        doc.WriteTo(tw);
                    }
                }
                textBox3.AppendText(String.Format(" {1}{1}{1}XML Formated:{1}{0}{1}", sb.ToString(), Environment.NewLine));
                
            }
        }



        private void DysplayError(Exception ex)
        {
            MessageBox.Show(String.Format("Error: {0}{1}Stack:{1}{2}", ex.Message, Environment.NewLine, ex.StackTrace));
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            try
            {
                var response = await Client.GetAsync(textBox1.Text);
                response.EnsureSuccessStatusCode();
                comboBox1.Items.Clear();
                string text = await response.Content.ReadAsStringAsync();
                Regex reg = new Regex("option\\W+value\\=\\\"([^\\\"]+)\\\"");
                MatchCollection matches = reg.Matches(text);
                foreach(Match m in matches)
                {
                    comboBox1.Items.Add(m.Groups[1].Value);
                }
                if (matches.Count == 0)
                {
                    MessageBox.Show("No Reliant Party found");
                    button1.Enabled = false;
                } else
                {
                    button1.Enabled = true;
                    comboBox1.SelectedIndex = 0;
                }

            } catch(Exception ex)
            {
                DysplayError(ex);
                return;
            }
        }


    }
}
