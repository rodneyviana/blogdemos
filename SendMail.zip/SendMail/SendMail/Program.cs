using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using System.Net.Mail;

namespace SendMail
{
    public class MailServerInfo
    {
        protected string server;

        public string Server
        {
            get { return server; }
        }
        protected string from;

        public string From
        {
            get { return from; }
        }
        protected string replyTo;

        public string ReplyTo
        {
            get { return replyTo; }
        }

        public MailServerInfo(SPSite spSite)
        {
            server = "(empty)";
            from = "(empty)";
            replyTo = "(empty)";
            SPWebApplication spWebApplication = spSite.WebApplication;
            if (spWebApplication.OutboundMailServiceInstance != null)
            {
                from = spWebApplication.OutboundMailSenderAddress;
                replyTo = spWebApplication.OutboundMailReplyToAddress;
                SPOutboundMailServiceInstance smtpServer = spWebApplication.OutboundMailServiceInstance;
                server = smtpServer.Server.Address;
            }

        }

        public string ServerInformation
        {
            get
            {
               return String.Format("Site Specific - server: {0}, From: {1}, ReplyTo: {2}",
                        server, from, replyTo);

            }
        }
    }

    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Sharepoint e-mail configuration tester");
            Console.WriteLine("======================================");
            Console.WriteLine("Written by Rodney Viana");
            Console.WriteLine("More info at http://blogs.msdn.com/rodneyviana\n");
            Console.WriteLine("This sample application is supplied \"AS IS\"");
            Console.WriteLine("It is ONLY for demonstration/proof of concept purposes");
            Console.WriteLine("If you DO NOT agree with the license at:\n\thttp://www.codeplex.com/rodneyviana/license\n\tPress Ctrl+C");
            Console.Write("Press any other key to continue...");
            Console.ReadKey();
            Console.Write("\n\nPlease enter url (eg.: http://localhost):");
            string siteUrl = Console.ReadLine();

            try
            {
                using (SPSite spSite = new SPSite(siteUrl))
                {
                    using (SPWeb web = spSite.OpenWeb())
                    {
                        if (web == null)
                        {
                            Console.WriteLine("Web could not be found (OpenWeb returned null). Aborting.");
                            return;
                        }
                        Console.WriteLine("The site has been found at " + web.Url);
                        Console.Write("Please enter recipient login name (eg. domain\\administrator): ");
                        string login = Console.ReadLine();
                        string displayName = "";
                        string emailAddress = "";
                        string SID = "";
                        string SIDB = "";
                        string principalType = "";
                        try
                        {
                            byte[] sidB = Users.ADVAPI.GetUserSID(login);
                            SID = Users.ADVAPI.GetSidString(sidB);
                            SIDB = Users.ADVAPI.ByteAsHexString(sidB);
                            Console.WriteLine("Sid: {0}", SID);
                            Console.WriteLine("Sid Internal: {0}", SIDB);
                        }
                        catch { }
                        try
                        {
                            SPPrincipalInfo userInfo = SPUtility.ResolvePrincipal(web,
                                login, SPPrincipalType.All, SPPrincipalSource.All, null, false);

                            displayName = userInfo.DisplayName;
                            emailAddress = userInfo.Email;
                            principalType = userInfo.PrincipalType.ToString();
                           
                            
                            //SPUtility.GetFullNameandEmailfromLogin(web, login, out displayName,
                            //    out emailAddress);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Unable to get user information.");
                            Console.WriteLine("Error: "+ex.Message);
                            Console.Write("Press any key...");
                            Console.ReadKey();

                            return;
                        }
                       

                        Console.WriteLine("Display Name: {0}\nE-mail: {1}", displayName,
                            emailAddress);
                        string subject = "Test message";
                        string body = "Testing app message";
                        MailServerInfo serverInfo = new MailServerInfo(spSite);

                        string server = serverInfo.Server;
                        string replyTo = serverInfo.ReplyTo;
                        string from = serverInfo.From;

                        Console.WriteLine(serverInfo.ServerInformation);
                        Console.WriteLine("Trying to send e-mail via Sharepoint...");

                        if (!SPUtility.SendEmail(web, true, true, emailAddress, subject, body))
                        {
                            Console.WriteLine("Error: Unable to send e-mail via Sharepoint");
                            Console.WriteLine("Trying via SMTP...");

                            SmtpClient client;
                            try
                            {
                                client = new SmtpClient(server);
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Could not contact server");
                                Console.WriteLine("Error: " + ex.Message);
                                Console.Write("Press any key...");
                                Console.ReadKey();

                                return;
                            }
                            try
                            {

                                client.Send(from, emailAddress, subject, body);

                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Unable to send via SMTP client");
                                Console.WriteLine("Error: " + ex.Message);
                                Console.Write("Press any key...");
                                Console.ReadKey();

                                return;
                            }
                            Console.WriteLine("E-mail has been sent successfully via SMTP client");


                        }
                        else
                        {
                            Console.WriteLine("E-mail has been sent successfully via Sharepoint");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to find url.");
                Console.WriteLine("Error: " + ex.Message);


            }
            Console.Write("Press any key...");
            Console.ReadKey();


        }
    
    }
}
