﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Win32;
using System.Windows.Forms;

namespace FixNetworkVisibility
{

    public class RegUtil
    {
        public static string RegistryLastError = null;

        public const string NetworkRegPath = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Profiles";

        public static RegistryKey OpenKey(string Path = NetworkRegPath, bool ReadOnly = true)
        {
            RegistryKey key = null;

            try
            {
                key = Registry.LocalMachine.OpenSubKey(Path, !ReadOnly);
            }
            catch (Exception ex)
            {
                RegistryLastError = String.Format("{0}: {1}", ex.GetType().ToString(), ex.Message);
            }

            return key;

        }

        public static string[] EnumSubKey(RegistryKey Key)
        {
            try
            {
                return Key.GetSubKeyNames();
            }
            catch (Exception ex)
            {
                RegistryLastError = String.Format("{0}: {1}", ex.GetType().ToString(), ex.Message);
            }

            return null;
        }

        public static T GetValue<T>(string Path, string Name)
        {
            string lastError = RegistryLastError;

            try
            {
                if (!String.IsNullOrEmpty(lastError))
                    RegistryLastError = null;
                using (RegistryKey key = OpenKey(Path))
                {
                    if (String.IsNullOrEmpty(lastError))
                    {
                        object value = key.GetValue(Name);
                        if (value != null)
                        {
                            return (T)value;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                RegistryLastError = String.Format("{0}: {1}", ex.GetType().ToString(), ex.Message);
            }
            finally
            {
                if (!String.IsNullOrEmpty(lastError) && String.IsNullOrEmpty(RegistryLastError))
                    RegistryLastError = lastError;
            }


            return default(T);

        }


        public static bool SetValue<T>(string Path, string Name, T Value)
        {
            string lastError = RegistryLastError;

            try
            {
                if (!String.IsNullOrEmpty(lastError))
                    RegistryLastError = null;
                using (RegistryKey key = OpenKey(Path, false))
                {
                    if (String.IsNullOrEmpty(lastError))
                    {
                        key.SetValue(Name, Value);
                        return true;

                    }
                }
            }
            catch (Exception ex)
            {
                RegistryLastError = String.Format("{0}: {1}", ex.GetType().ToString(), ex.Message);
            }
            finally
            {
                if (!String.IsNullOrEmpty(lastError) && String.IsNullOrEmpty(RegistryLastError))
                    RegistryLastError = lastError;
            }


            return false;

        }


    }

    public class NetworkVisibility
    {


        public string Description
        {
            get;
            internal set;
        }


        public VisibilityType NetworkScope
        {
            get
            {
                if (String.IsNullOrEmpty(FullPath))
                    return VisibilityType.Public;
                return (VisibilityType)RegUtil.GetValue<int>(this.FullPath, "Category");
            }
            set
            {
                if (String.IsNullOrEmpty(FullPath))
                {
                    return;
                }

                VisibilityType visibility = (VisibilityType)RegUtil.GetValue<int>(this.FullPath, "Category");

                if(value != visibility)
                {
                    if (MessageBox.Show(String.Format("Do you want to change network context for {0} from {1} to {2}",
                        this.Description, visibility, value), "Warning", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {

                        if (!RegUtil.SetValue<int>(this.FullPath, "Category", (int)value))
                        {
                            MessageBox.Show(String.Format("Unable to change network {0} from {1} to {2}. Error: {3}",
                                this.Description, visibility, value, RegUtil.RegistryLastError),
                            "Unable to do the operation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("No Change was made", "Information", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                    }

                }
            }
        }

        public string FullPath
        {
            get;
            set;
        }

        public static IList<NetworkVisibility> GetList()
        {
            List<NetworkVisibility> nvl = new List<NetworkVisibility>();

            using (var reg = RegUtil.OpenKey())
            {
                string[] list = RegUtil.EnumSubKey(reg);
                foreach (string k in list)
                {
                    NetworkVisibility nv = new NetworkVisibility();
                    nv.FullPath = String.Format("{0}\\{1}", RegUtil.NetworkRegPath,
                        k);
                    nv.Description = RegUtil.GetValue<string>(nv.FullPath, "ProfileName");
                    nv.NetworkScope = (VisibilityType)RegUtil.GetValue<int>(String.Format("{0}\\{1}", RegUtil.NetworkRegPath,
                        k), "Category");

                    nvl.Add(nv);

                }
            }
            return nvl;
        }

    }

    public enum VisibilityType
    {
        Public = 0,
        Private = 1,
        Domain = 2
    }


}
