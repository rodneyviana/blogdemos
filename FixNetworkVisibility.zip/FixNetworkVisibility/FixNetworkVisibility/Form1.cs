﻿// This sample code is provided “AS IS” with no guarantees and its meant for proof-of-concept ONLY. 
// You need to accept this license to use it: http://rodneyviana.codeplex.com/license

//The code samples are provided AS IS without warranty of any kind.
// The author disclaims all implied warranties including, without limitation,
// any implied warranties of merchantability or of fitness for a particular purpose. The entire risk arising out of the use or performance of the sample scripts and documentation remains with you. In no event shall Microsoft, its authors, or anyone else involved in the creation, production, or delivery of the scripts be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, business interruption, loss of business information, or other pecuniary loss) arising out of the use of or inability to use the sample scripts or documentation, even if Microsoft has been advised of the possibility of such damages. 


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FixNetworkVisibility
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public IList<NetworkVisibility> AllList = null;
        private void button1_Click(object sender, EventArgs e)
        {
            if(!checkBox1.Checked)
            {
                if(MessageBox.Show("If you click yes, you confirm you have read the license at http://rodneyviana.codeplex.com and accepted", "I do accept the license",
                    MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                {
                    checkBox1.Checked = true;
                } else
                {
                    return;
                }
            }
            checkBox1.Enabled = false;
            AllList = NetworkVisibility.GetList();
            DataGridViewComboBoxColumn col = dataGridView1.Columns[1] as DataGridViewComboBoxColumn;
            if (col != null)
            {
                col.DataSource = Enum.GetValues(typeof(VisibilityType));
                col.ValueType = typeof(VisibilityType);
            }
            dataGridView1.DataSource = AllList;

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("http://rodneyviana.codeplex.com/license");
        }
    }
}
