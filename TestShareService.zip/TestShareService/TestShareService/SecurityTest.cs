﻿using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace TestShareService
{
    public enum SE_OBJECT_TYPE
    {
        SE_UNKNOWN_OBJECT_TYPE = 0,
        SE_FILE_OBJECT,
        SE_SERVICE,
        SE_PRINTER,
        SE_REGISTRY_KEY,
        SE_LMSHARE,
        SE_KERNEL_OBJECT,
        SE_WINDOW_OBJECT,
        SE_DS_OBJECT,
        SE_DS_OBJECT_ALL,
        SE_PROVIDER_DEFINED_OBJECT,
        SE_WMIGUID_OBJECT,
        SE_REGISTRY_WOW64_32KEY
    }

    [Flags]
    public enum SECURITY_INFORMATION : uint
    {
        OWNER_SECURITY_INFORMATION = 0x00000001,
        GROUP_SECURITY_INFORMATION = 0x00000002,
        DACL_SECURITY_INFORMATION = 0x00000004,
        SACL_SECURITY_INFORMATION = 0x00000008,
        UNPROTECTED_SACL_SECURITY_INFORMATION = 0x10000000,
        UNPROTECTED_DACL_SECURITY_INFORMATION = 0x20000000,
        PROTECTED_SACL_SECURITY_INFORMATION = 0x40000000,
        PROTECTED_DACL_SECURITY_INFORMATION = 0x80000000,
        ATTRIBUTE_SECURITY_INFORMATION = 0x00000020,
        BACKUP_SECURITY_INFORMATION = 0x00010000,
        SCOPE_SECURITY_INFORMATION = 0x00000040,
    }

    public class SecurityTest
    {
        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        public static extern bool LogonUser(String lpszUsername, String lpszDomain, String lpszPassword,
            int dwLogonType, int dwLogonProvider, out SafeTokenHandle phToken);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        public extern static bool CloseHandle(IntPtr handle);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern IntPtr LocalFree(IntPtr hMem);

        [DllImport("advapi32.dll", CharSet = CharSet.Auto)]
        static extern int GetNamedSecurityInfo(
            string pObjectName,
            SE_OBJECT_TYPE ObjectType,
            SECURITY_INFORMATION SecurityInfo,
            out IntPtr pSidOwner,
            out IntPtr pSidGroup,
            out IntPtr pDacl,
            out IntPtr pSacl,
            out IntPtr pSecurityDescriptor);

        const int FACILITY_WIN32 = unchecked((int)0x80070000);
        static int HRESULT_FROM_WIN32(int x)
        {
            return x < 0 ? x : x | FACILITY_WIN32;
        }

        public static string GetFileObjectOwner(string objectName)
        {
            IntPtr pZero = IntPtr.Zero;
            IntPtr pSid = pZero;
            IntPtr psd = pZero;
            IntPtr psd1 = pZero;
            IntPtr pSid1 = pZero;

            SECURITY_INFORMATION si = SECURITY_INFORMATION.OWNER_SECURITY_INFORMATION |
                SECURITY_INFORMATION.GROUP_SECURITY_INFORMATION |
                SECURITY_INFORMATION.DACL_SECURITY_INFORMATION;
            int errorReturn = GetNamedSecurityInfo(objectName,
                SE_OBJECT_TYPE.SE_FILE_OBJECT,
                si,
                out pSid, out pZero, out pZero, out pZero, out psd);

            if (errorReturn != 0)
            {
                return String.Format("Error: GetNamedSecurityInfo: 0x{0:x} {1}", HRESULT_FROM_WIN32(errorReturn), si.ToString());

            }
            si |= SECURITY_INFORMATION.BACKUP_SECURITY_INFORMATION |
                SECURITY_INFORMATION.SACL_SECURITY_INFORMATION |
                SECURITY_INFORMATION.ATTRIBUTE_SECURITY_INFORMATION |
                SECURITY_INFORMATION.SCOPE_SECURITY_INFORMATION;

            errorReturn = GetNamedSecurityInfo(objectName,
                SE_OBJECT_TYPE.SE_FILE_OBJECT,
                si,
                out pSid1, out pZero, out pZero, out pZero, out psd1);

            if (errorReturn != 0)
            {
                return String.Format("Error: GetNamedSecurityInfo: 0x{0:x} {1}", HRESULT_FROM_WIN32(errorReturn), si.ToString());

            }

            LocalFree(psd);
            LocalFree(psd1);
            return "Success";

        }

    }

    public sealed class SafeTokenHandle : SafeHandleZeroOrMinusOneIsInvalid
    {
        private SafeTokenHandle()
            : base(true)
        {
        }

        [DllImport("kernel32.dll")]

        private static extern bool CloseHandle(IntPtr handle);

        protected override bool ReleaseHandle()
        {
            return CloseHandle(handle);
        }
    }
}
