﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace TestShareService
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            string pathList = System.Configuration.ConfigurationSettings.AppSettings["Folders"];

            WriteLog.WriteInformationEvent("Folders list: "+pathList);
            string[] paths = pathList.Split(new Char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string path in paths)
            {
                string result = SecurityTest.GetFileObjectOwner(path);
                WriteLog.WriteInformationEvent(path+" "+result);
            }
            WriteLog.WriteInformationEvent("End of test!");

        }

        protected override void OnStop()
        {
        }
    }
}
