﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Configuration.Install;
using System.Reflection;
using System.IO;
using System.Security;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Threading;

namespace TestShareService
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static int Main(string[] args)
        {
            
            ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[] 
            { 
                new Service1() 
            };

            if (System.Environment.UserInteractive)
            {

                if (args.Length != 1 || args[0] == "?" || (args[0].Replace("-", "/") + "   ").Substring(0, 2) == "/h")
                {
                    if (Console.IsOutputRedirected)
                    {
                        ConsoleManager.Show();
                    };
                    Console.WriteLine("Test Share Access Service");
                    Console.WriteLine("=========================");
                    Console.WriteLine("Syntax: TestShareService.exe [/i] [/u]");
                    Console.WriteLine("Where:");
                    Console.WriteLine("\t/i install the service");
                    Console.WriteLine("\t/u uninstall the service");
                    Console.Write("Press any key...");
                    Console.ReadKey();
                    //Thread.Sleep(5000);
                    return 0; // ok

                }

                // we only care about the first two characters
                string arg = args[0].Replace("-", "/").ToLowerInvariant().Substring(0, 2);

                string PathToSelf = Assembly.GetExecutingAssembly().Location;


                switch (arg)
                {
                    case "/i":  // install
                        try
                        {
                            ManagedInstallerClass.InstallHelper(
                                new string[] { PathToSelf });
                            WriteLog.WriteInformationEvent("Service installed successfully");

                            return 0;
                        }
                        catch (Exception ex)
                        {
                            WriteLog.WriteErrorEvent(String.Format("Installation failed: {0} {1}", ex.GetType().ToString(), ex.Message));
                            return -1;
                        }
                        break;
                    case "/u":  // uninstall
                        try
                        {
                            ManagedInstallerClass.InstallHelper(
                                new string[] { "/u", PathToSelf });
                            WriteLog.WriteInformationEvent("Service uninstalled successfully");
                            return 0;
                        }
                        catch (Exception ex)
                        {
                            WriteLog.WriteErrorEvent(String.Format("Uninstallation failed: {0} {1}", ex.GetType().ToString(), ex.Message));
                            return -1;
                        }
                        break;
                    default:  // unknown option
                        Console.WriteLine("Invalid option: {0}", args[0]);
                        Console.WriteLine(string.Empty);

                        return -1;
                }
            }



            ServiceBase.Run(ServicesToRun);
            return 0;
        }
    }

    [SuppressUnmanagedCodeSecurity]
    public static class ConsoleManager
    {
        private const string Kernel32_DllName = "kernel32.dll";

        [DllImport(Kernel32_DllName)]
        private static extern bool AllocConsole();

        [DllImport(Kernel32_DllName)]
        private static extern bool FreeConsole();

        [DllImport(Kernel32_DllName)]
        private static extern IntPtr GetConsoleWindow();

        [DllImport(Kernel32_DllName)]
        private static extern int GetConsoleOutputCP();

        public static bool HasConsole
        {
            get { return GetConsoleWindow() != IntPtr.Zero; }
        }

        /// <summary>
        /// Creates a new console instance if the process is not attached to a console already.
        /// </summary>
        public static void Show()
        {
            //#if DEBUG
            if (!HasConsole)
            {
                AllocConsole();
                InvalidateOutAndError();
            }
            //#endif
        }
        static void InvalidateOutAndError()
        {
            Type type = typeof(System.Console);

            System.Reflection.FieldInfo _out = type.GetField("_out",
                System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic);

            System.Reflection.FieldInfo _error = type.GetField("_error",
                System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic);

            System.Reflection.MethodInfo _InitializeStdOutError = type.GetMethod("InitializeStdOutError",
                System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic);

            Debug.Assert(_out != null);
            Debug.Assert(_error != null);

            Debug.Assert(_InitializeStdOutError != null);

            _out.SetValue(null, null);
            _error.SetValue(null, null);

            _InitializeStdOutError.Invoke(null, new object[] { true });
        }
    }
}
